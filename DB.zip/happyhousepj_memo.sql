-- MySQL dump 10.13  Distrib 8.0.26, for macos11 (x86_64)
--
-- Host: localhost    Database: happyhousepj
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `memo`
--

DROP TABLE IF EXISTS `memo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `memo` (
  `memono` int NOT NULL AUTO_INCREMENT,
  `userid` varchar(16) DEFAULT NULL,
  `comment` varchar(500) DEFAULT NULL,
  `memotime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `articleno` int DEFAULT NULL,
  PRIMARY KEY (`memono`),
  KEY `memo_to_board_fk` (`articleno`),
  KEY `memo_to_member_fk_idx` (`userid`),
  CONSTRAINT `memo_to_board_fk` FOREIGN KEY (`articleno`) REFERENCES `notice` (`articleno`) ON DELETE CASCADE,
  CONSTRAINT `memo_to_member_fk` FOREIGN KEY (`userid`) REFERENCES `house_member` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `memo`
--

LOCK TABLES `memo` WRITE;
/*!40000 ALTER TABLE `memo` DISABLE KEYS */;
INSERT INTO `memo` VALUES (36,'관리자','발표자료 마지막에 정리해놓았습니다.','2021-11-25 13:32:12',41),(37,'관리자','로그인 화면 아래에 비밀번호 찾기가 있습니다.','2021-11-25 13:32:41',42),(38,'관리자','감사합니다.','2021-11-25 13:32:51',43),(39,'안세연','동감합니다!','2021-11-25 13:33:51',43),(40,'김주향','강남역 근처 추천합니다. 아파트 매매정보 메뉴를 사용해보세요.','2021-11-25 13:37:08',44),(42,'minsu7','저 강남구 살아요!','2021-11-25 13:49:57',45),(43,'minsu7','아파트 매매정보 메뉴에 잘 나와있어요!!','2021-11-25 13:52:55',44);
/*!40000 ALTER TABLE `memo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-26  1:23:02

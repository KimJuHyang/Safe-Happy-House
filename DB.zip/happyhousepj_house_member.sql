-- MySQL dump 10.13  Distrib 8.0.26, for macos11 (x86_64)
--
-- Host: localhost    Database: happyhousepj
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `house_member`
--

DROP TABLE IF EXISTS `house_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `house_member` (
  `userid` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `userpwd` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(50) DEFAULT NULL,
  `joindate` date DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `house_member`
--

LOCK TABLES `house_member` WRITE;
/*!40000 ALTER TABLE `house_member` DISABLE KEYS */;
INSERT INTO `house_member` VALUES ('admin','admin','admin','admin@ss.com','서울fh',NULL),('asy','asy','O5mh0hnGll','asy@nn.com','asy',NULL),('guest1','guest1','g123','gg@gg.com','ggg','2021-11-03'),('jgh','jgh','jgh','jgh@n.com','jgh',NULL),('jh','jh','jh','jh','안뇽쓰','2021-11-24'),('juhyang','1','1','juhyang@naver.com','인천 계양구','2021-11-26'),('kimssafy','김싸피','ssafy','kim@ssafy.com','서울시 강남구','2021-11-17'),('minsu7','1','1','1@n.com','1','2021-11-25'),('q','q','YRm3pxS41V','q@naver.com',NULL,'2021-11-25'),('sdfsdf','sdfggggㅁㅁ','sdfsdf','sdfhhh','sdf','2021-11-18'),('ssafy','ssafy','ssafy','ssafy@ss.com','ssafyssafy',NULL),('user1','user1','u123','uu@uus.com','uuu','2021-11-03'),('관리자','관리자','1','i@naver.com','인천','2021-11-25'),('김주향','김주향','lxnjXghfyn','1@naver.com',NULL,'2021-11-25'),('안세연','안세연','1','1@n.com','서울','2021-11-25');
/*!40000 ALTER TABLE `house_member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-26  1:23:01

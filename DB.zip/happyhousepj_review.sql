-- MySQL dump 10.13  Distrib 8.0.26, for macos11 (x86_64)
--
-- Host: localhost    Database: happyhousepj
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
  `reviewno` int NOT NULL AUTO_INCREMENT,
  `userid` varchar(16) DEFAULT NULL,
  `review` varchar(500) DEFAULT NULL,
  `reviewtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `aptName` varchar(20) DEFAULT NULL,
  `grade` int DEFAULT NULL,
  PRIMARY KEY (`reviewno`),
  KEY `review_to_house_member_fk_idx` (`userid`),
  CONSTRAINT `review_to_house_member_fk_idx` FOREIGN KEY (`userid`) REFERENCES `house_member` (`userid`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (53,'김주향','공원과 가까워서 정말 좋아요 !','2021-11-25 13:43:44','신동아블루아광화문의꿈',5),(54,'김주향','건물이 너무 낡아서 별로입니다.','2021-11-25 13:44:37','풍림',1),(55,'안세연','지하철역과 거리가 먼 것 빼고 만족해요','2021-11-25 13:45:36','신동아블루아광화문의꿈',4),(56,'안세연','밤에 너무 시끄러워요 ㅠㅠ','2021-11-25 13:46:25','경희궁파크팰리스',2),(57,'안세연','주변에 맛있는 빵집이 있어서 좋아요 ㅎㅎ','2021-11-25 13:47:24','풍림',4),(58,'minsu7','주변에 맛집이 많아서 좋습니다.','2021-11-25 13:50:49','신동아블루아광화문의꿈',5),(59,'minsu7','바퀴벌레가 나옵니다.','2021-11-25 13:51:13','경희궁파크팰리스',1),(60,'ssafy','최고입니다.','2021-11-25 14:04:24','신동아블루아광화문의꿈',5),(61,'ssafy','최고에요!','2021-11-25 14:04:38','경희궁의아침2단지',5),(62,'ssafy','아주 좋아요.','2021-11-25 14:07:09','신동아블루아광화문의꿈',5),(64,'ssafy','최고입니다.','2021-11-25 14:15:07','신동아블루아광화문의꿈',3),(65,'ssafy','최고에요','2021-11-25 14:15:22','경희궁의아침2단지',5),(66,'ssafy','3','2021-11-25 14:51:37','금호',3),(67,'ssafy','3','2021-11-25 14:51:55','우남이채롬',3),(68,'ssafy','w','2021-11-25 15:06:13','춘천요선동한신휴플러스',5),(69,'ssafy','g','2021-11-25 15:06:33','미도파',5),(70,'ssafy','h','2021-11-25 15:08:39','뜰안채주상복합',5),(71,'ssafy','g','2021-11-25 15:08:45','현대',5);
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-26  1:23:02

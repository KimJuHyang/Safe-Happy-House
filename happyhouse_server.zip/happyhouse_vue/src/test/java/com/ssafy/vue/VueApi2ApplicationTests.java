package com.ssafy.vue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VueApi2ApplicationTests {

	@Test
	void contextLoads() {
	}

}

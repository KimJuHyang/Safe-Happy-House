package com.ssafy.happyhouse.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.model.ReviewDto;
import com.ssafy.happyhouse.model.mapper.ReviewMapper;

@Service
public class ReviewServiceImpl implements ReviewService{
	
	@Autowired
	private ReviewMapper reviewMapper;
	
	@Override
	public List<ReviewDto> list(String aptName) {
		return reviewMapper.list(aptName);
	}

	@Override
	public boolean create(ReviewDto reviewDto) {
		return reviewMapper.create(reviewDto) == 1;
	}

	@Override
	public boolean modify(ReviewDto reviewDto) {
		return reviewMapper.modify(reviewDto) == 1;
	}

	@Override
	public boolean delete(int reviewno) {
		return reviewMapper.delete(reviewno) == 1;
	}

	@Override
	public Integer findAptCode(String aptName) {
		return reviewMapper.findAptCode(aptName);
	}
}

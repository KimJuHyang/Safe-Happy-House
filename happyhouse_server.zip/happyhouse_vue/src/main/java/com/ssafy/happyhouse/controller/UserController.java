package com.ssafy.happyhouse.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.model.NoticeDto;
import com.ssafy.happyhouse.model.UserDto;
import com.ssafy.happyhouse.model.service.JwtServiceImpl;
import com.ssafy.happyhouse.model.service.UserService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/user")
@Api("유저 컨트롤러  API V1")
public class UserController {

	private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	private static final String SUCCESS = "success";
	private static final String FAIL = "fail";
	
	@Autowired
	private JwtServiceImpl jwtService;
	
	@Autowired
	private UserService service;
	
	@ApiOperation(value = "로그인", notes = "Access-token과 로그인 결과 메세지를 반환한다.", response = Map.class)
	@PostMapping("/login")
	public ResponseEntity<Map<String, Object>> login(
			@RequestBody @ApiParam(value = "로그인 시 필요한 회원정보(아이디, 비밀번호).", required = true) UserDto userDto) {
		Map<String, Object> resultMap = new HashMap<>();
		HttpStatus status = null;
		try {
			UserDto loginUser = service.login(userDto);
			if (loginUser != null) {
				String token = jwtService.create("userid", loginUser.getUserid(), "access-token");// key, data, subject
				logger.debug("로그인 토큰정보 : {}", token);
				resultMap.put("access-token", token);
				resultMap.put("message", SUCCESS);
				status = HttpStatus.ACCEPTED;
			} else {
				resultMap.put("message", FAIL);
				status = HttpStatus.ACCEPTED;
			}
		} catch (Exception e) {
			logger.error("로그인 실패 : {}", e);
			resultMap.put("message", e.getMessage());
			status = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		return new ResponseEntity<Map<String, Object>>(resultMap, status);
	}
	
	@ApiOperation(value = "회원인증", notes = "회원 정보를 담은 Token을 반환한다.", response = Map.class)
	@GetMapping("/info/{userid}")
	public ResponseEntity<Map<String, Object>> getInfo(
			@PathVariable("userid") @ApiParam(value = "인증할 회원의 아이디.", required = true) String userid,
			HttpServletRequest request) {
//		logger.debug("userid : {} ", userid);
		Map<String, Object> resultMap = new HashMap<>();
		HttpStatus status = HttpStatus.ACCEPTED;
		if (jwtService.isUsable(request.getHeader("access-token"))) {
			logger.info("사용 가능한 토큰!!!");
			try {
//				로그인 사용자 정보.
				UserDto userDto = service.userInfo(userid);
				resultMap.put("userInfo", userDto);
				resultMap.put("message", SUCCESS);
				status = HttpStatus.ACCEPTED;
			} catch (Exception e) {
				logger.error("정보조회 실패 : {}", e);
				resultMap.put("message", e.getMessage());
				status = HttpStatus.INTERNAL_SERVER_ERROR;
			}
		} else {
			logger.error("사용 불가능 토큰!!!");
			resultMap.put("message", FAIL);
			status = HttpStatus.ACCEPTED;
		}
		return new ResponseEntity<Map<String, Object>>(resultMap, status);
	}
	
	@PostMapping
	@ApiOperation(value="member 등록 서비스")
	public ResponseEntity<String> insetMember(@RequestBody @ApiParam(value = "유저 정보.", required = true)UserDto userDto) throws Exception {
		logger.info("insetMember - 호출");
		if (service.regMember(userDto)) {
			return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
		}
		return new ResponseEntity<String>(FAIL, HttpStatus.NO_CONTENT);

	}
	
	@PutMapping
	@ApiOperation(value="member 수정 서비스")
	public ResponseEntity<String> updateMember(@RequestBody @ApiParam(value = "수정할 유저 정보.", required = true) UserDto userDto) throws Exception {
		logger.info("updateMember - 호출");
		
		if (service.updateMember(userDto)) {
			return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
		}
		return new ResponseEntity<String>(FAIL, HttpStatus.OK);
	}
	
	@GetMapping("/pwd")
	@ApiOperation(value="member 비밀번호 찾기 서비스")
	public ResponseEntity<UserDto> findPw(@ApiParam(value = "수정할 유저 정보.", required = true) UserDto userDto) throws Exception {
		logger.info("findId - 호출");
		if(service.findId(userDto)) {
		String newpwd = service.randomPwd(userDto);
		service.updateMember(userDto);
		System.out.println(userDto);
		return new ResponseEntity<UserDto>(userDto, HttpStatus.OK);
		}else {
			return new ResponseEntity<UserDto>(userDto, HttpStatus.NO_CONTENT);
		}
		
	}

	
	@DeleteMapping("/{userid}")
	@ApiOperation(value="member 삭제 서비스")
	public ResponseEntity<String> deleteMember(@PathVariable("userid") @ApiParam(value = "살제할 유저 아이디.", required = true) String userid) throws Exception {
		logger.info("deleteMember - 호출");
		if (service.delMember(userid)) {
			return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
		}
		return new ResponseEntity<String>(FAIL, HttpStatus.NO_CONTENT);

	}
	
	@GetMapping("/{userid}")
	@ApiOperation(value="userid을 받아 member 조회 서비스", notes = "유저의 정보를 반환한다.", response=UserDto.class)
	public ResponseEntity<UserDto> getMember(@PathVariable("userid") @ApiParam(value = "얻어올 유저 아이디.", required = true) String userid) throws Exception {
		logger.info("getMember - 호출 : " + userid);
		return new ResponseEntity<UserDto>(service.getMember(userid), HttpStatus.OK);

	}
	
//	@RequestMapping(value = "/memlist", method = {RequestMethod.GET})
//	@GetMapping("/member")
//	@ApiOperation(value="member 조회 서비스", response=List.class)
//	public @ResponseBody ResponseEntity<Map<String, Object>> listMember() {
//		ResponseEntity<Map<String, Object>> resEntity = null;
//		List<MemberDTO> list = null;
//		try {
//			list = ser.listMember();
//			Map<String, Object> map = new HashMap<String, Object>();
//			map.put("resmsg", "조회 성공");
//			map.put("resValue", list);
//			resEntity = new ResponseEntity<Map<String,Object>>(map, HttpStatus.OK);
//		} catch (Exception e) {
//			// TODO: handle exception
//			Map<String, Object> map = new HashMap<String, Object>();
//			map.put("resmsg", "조회 실패");
//			resEntity = new ResponseEntity<Map<String,Object>>(map, HttpStatus.OK);
//		}
//		return resEntity;
//	}
}

package com.ssafy.happyhouse.model.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.happyhouse.model.UserDto;
import com.ssafy.happyhouse.model.mapper.UserMapper;
import com.ssafy.util.PageNavigation;


@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private SqlSession session;
	
	@Override
	public UserDto login(UserDto userDto) throws Exception {
		if(userDto.getUserid() == null || userDto.getUserpwd() == null)
			return null;
		return session.getMapper(UserMapper.class).login(userDto);
	}

	@Override
	public UserDto userInfo(String userid) throws Exception {
		return session.getMapper(UserMapper.class).userInfo(userid);
	}

	@Override
	public boolean idCheck(String id) throws Exception {
		Map<String , String> m = new HashMap();
		m.put("id",id);
		
		UserDto login = session.getMapper(UserMapper.class).idCheck(id);
		if(login != null) return true;
		else return false;	
	}
	
	@Override
	@Transactional
	public boolean regMember(UserDto userDto) throws Exception {
		if(userDto.getUserid() == null 
				|| userDto.getUsername() == null
				|| userDto.getUserpwd() == null
				|| userDto.getEmail() == null) {
			throw new Exception();
		}
		return session.getMapper(UserMapper.class).regMember(userDto) == 1;
	}

	@Override
	public List<UserDto> listMember() throws Exception {
		// TODO Auto-generated method stub
		List<UserDto> list = session.getMapper(UserMapper.class).listMember();
		return list;
	}

	@Override
	@Transactional
	public boolean delMember(String userid) throws Exception {
		return session.getMapper(UserMapper.class).delMember(userid) == 1;
	}

	@Override
	@Transactional
	public boolean updateMember(UserDto userDto)  throws Exception{
		return session.getMapper(UserMapper.class).updateMember(userDto) == 1;
		
	}

	@Override
	public List<UserDto> listMember(int currentPage, int sizePerPage) throws Exception {
		// TODO Auto-generated method stub
		Map<String , Integer> m = new HashMap();
		m.put("currentPage",(currentPage - 1) * sizePerPage);
		m.put("sizePerPage",sizePerPage);
		
		return session.getMapper(UserMapper.class).listMemberPage(m);
	}

	@Override
	public PageNavigation makePageNavigation(int currentPage, int sizePerPage) throws Exception {
		int naviSize = 10;
		PageNavigation pageNavigation = new PageNavigation();
		pageNavigation.setCurrentPage(currentPage);
		pageNavigation.setNaviSize(naviSize);
		
		List<UserDto> list = session.getMapper(UserMapper.class).listMember();
		int totalSize = list.size();
		pageNavigation.setTotalCount(totalSize);
		int totalPageSize = (totalSize - 1)/sizePerPage + 1;
		pageNavigation.setTotalPageCount(totalPageSize);
		boolean startRange = currentPage <= naviSize;
		pageNavigation.setStartRange(startRange);
		boolean endRange = (totalPageSize - 1)/naviSize * naviSize < currentPage;
		pageNavigation.setEndRange(endRange);
		pageNavigation.makeNavigator();
		return pageNavigation;
	}

	@Override
	public UserDto getMember(String userid) throws Exception {
		return session.getMapper(UserMapper.class).getMember(userid);
	}

	@Override
	public String randomPwd(UserDto userDto) {
		//random 함수
		int leftLimit = 48; // numeral '0'
		int rightLimit = 122; // letter 'z'
		int targetStringLength = 10;
		Random random = new Random();
	
		String generatedString = random.ints(leftLimit,rightLimit + 1)
	  .filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
	  .limit(targetStringLength)
	  .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
	  .toString();
		userDto.setUserpwd(generatedString);
		return generatedString;
	}

	@Override
	public boolean findId(UserDto userDto) {
		if(userDto.getUserid() == null || userDto.getEmail() == null)
			return false;
		else {
		UserDto findId = session.getMapper(UserMapper.class).findId(userDto);
		if(findId != null)
			return true;
		else
			return false;
		}
	}
}

package com.ssafy.happyhouse.model.service;

import java.util.List;

import com.ssafy.happyhouse.model.UserDto;
import com.ssafy.util.PageNavigation;


public interface UserService {
	public UserDto login(UserDto userDto)  throws Exception;
	public boolean idCheck(String userid)  throws Exception;
	public UserDto userInfo(String userid) throws Exception;
	public boolean regMember(UserDto userDto)  throws Exception;
	public List<UserDto> listMember()  throws Exception;
	public List<UserDto> listMember(int currentPage, int sizePerPage)  throws Exception;
	public UserDto getMember(String userid) throws Exception;
	public boolean delMember(String userid)  throws Exception;
	public boolean updateMember(UserDto userDto)  throws Exception;
	public PageNavigation makePageNavigation(int currentPage, int sizePerPage)  throws Exception;
	public boolean findId(UserDto userDto);
	public String randomPwd(UserDto userDto);
}

package com.ssafy.happyhouse.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.model.CommentDto;
import com.ssafy.happyhouse.model.ReviewDto;
import com.ssafy.happyhouse.model.service.CommentService;
import com.ssafy.happyhouse.model.service.ReviewService;

import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = { "*" }, maxAge = 6000)
@RestController
@RequestMapping("/review")
public class ReviewController {

	private static final Logger logger = LoggerFactory.getLogger(ReviewController.class);
	private static final String SUCCESS = "success";
	private static final String FAIL = "fail";
	
	@Autowired
	ReviewService reviewService;

	@ApiOperation(value = "aptCode에 해당하는 댓글을 반환한다.", response = List.class)
	@GetMapping("{aptName}")
	public ResponseEntity<List<ReviewDto>> listReview(@PathVariable("aptName") String aptName) {
		logger.debug("listReview - 호출");
		// 아파트 이름으로 일려번호 불러오기
		System.out.println(aptName);
//		Integer aptCode = reviewService.findAptCode(aptName);
//		if(aptCode != null) {
//		return new ResponseEntity<>(reviewService.list(aptCode), HttpStatus.OK);
//		}
//		else {
//			return new ResponseEntity<>(reviewService.list(0), HttpStatus.NO_CONTENT);
//		}
		return new ResponseEntity<>(reviewService.list(aptName), HttpStatus.OK);
	}

	@ApiOperation(value = "새로운 댓글을 입력한다. 그리고 DB입력 성공여부에 따라 'success' 또는 'fail' 문자열을 반환한다.", response = String.class)
	@PostMapping
	public ResponseEntity<String> createReview(@RequestBody ReviewDto reviewDto) {
		logger.debug("createReview - 호출");
		if(reviewService.create(reviewDto)) {
			return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
		}
		return new ResponseEntity<String>(FAIL, HttpStatus.NO_CONTENT);
	}

	@ApiOperation(value = "댓글번호가 memono에 해당하는 댓글을 수정한다. 그리고 DB수정 성공여부에 따라 'success' 또는 'fail' 문자열을 반환한다.", response = String.class)
	@PutMapping
	public ResponseEntity<String> modifyReview(@RequestBody ReviewDto reviewDto) {
		logger.debug("modifyReview - 호출");
		logger.debug("" + reviewDto);
		System.out.println("댓글 수정하자!!!"  + reviewDto);
		if(reviewService.modify(reviewDto)) {
			System.out.println("댓글 수정 성공!!!");
			return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
		}
		return new ResponseEntity<String>(FAIL, HttpStatus.NO_CONTENT);
	}

	@ApiOperation(value = "댓글번호가 memono에 해당하는 댓글을 삭제한다. 그리고 DB삭제 성공여부에 따라 'success' 또는 'fail' 문자열을 반환한다.", response = String.class)
	@DeleteMapping("{reviewno}")
	public ResponseEntity<String> deleteReview(@PathVariable("reviewno") int reviewno) {
		logger.debug("deleteReview - 호출");
		if(reviewService.delete(reviewno)) {
			return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
		}
		return new ResponseEntity<String>(FAIL, HttpStatus.NO_CONTENT);
	}
	
}

package com.ssafy.happyhouse.model.service;

import java.util.List;

import com.ssafy.happyhouse.model.ReviewDto;

public interface ReviewService {
	List<ReviewDto> list(String aptName);

	boolean create(ReviewDto reviewDto);

	boolean modify(ReviewDto reviewDto);

	boolean delete(int reviewno);
	
	Integer findAptCode(String aptName);
}

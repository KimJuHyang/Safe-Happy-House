package com.ssafy.happyhouse.model.mapper;

import java.util.List;

import com.ssafy.happyhouse.model.ReviewDto;

public interface ReviewMapper {
	List<ReviewDto> list(String aptName);

	int create(ReviewDto reviewDto);

	int modify(ReviewDto reviewDto);

	int delete(int reviewno);
	
	Integer findAptCode(String aptName);
}

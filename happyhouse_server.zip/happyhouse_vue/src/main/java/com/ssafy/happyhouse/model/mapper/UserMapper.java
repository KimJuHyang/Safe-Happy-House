package com.ssafy.happyhouse.model.mapper;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.happyhouse.model.UserDto;

@Mapper
public interface UserMapper {
	public UserDto idCheck(String userid) throws Exception;
	public UserDto login(UserDto userDto)  throws Exception;
	public int regMember(UserDto userDto)  throws Exception;
	public List<UserDto> listMember()  throws Exception;
	public List<UserDto> listMemberPage(Map userDto)  throws Exception;
	public int delMember(String userid)  throws Exception;
	public int updateMember(UserDto userDto)  throws Exception;
	public UserDto getMember(String userid) throws SQLException;
	public UserDto userInfo(String userid) throws SQLException;
	public UserDto findId(UserDto userDto);
}

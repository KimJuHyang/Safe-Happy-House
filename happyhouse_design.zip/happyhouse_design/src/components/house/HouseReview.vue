<template>
  <div>
    <div class="main">
      <div class="responsive-wrapper">
        <div class="content-header" style="padding-left: 35%">
          <div class="content-header-intro">
            <h2>{{ aptName }}</h2>
            <p v-if="avg != 0">
              평균 별점 {{ avg }}
              <grade-for v-for="(avgi, index) in avg" :key="index" />
            </p>
            <p v-else>등록된 리뷰가 없습니다.</p>
          </div>
        </div>

        <div class="context text-center">
          <review-write :aptName="this.aptName" />
          <review-write
            v-if="isModifyShow && this.modifyReview != null"
            :modifyReview="this.modifyReview"
            @modify-review-cancel="onModifyReviewCancel"
          />
          <review
            v-for="(review, index) in reviews"
            :key="index"
            :review="review"
            @modify-review="onModifyReview"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
//import http from "@/util/http-common";
import GradeFor from "@/components/house/review/GradeFor.vue";
import { mapGetters, mapState } from "vuex";
import ReviewWrite from "@/components/house/review/ReviewWrite.vue";
import Review from "@/components/house/review/Review.vue";
//import { mapState, mapActions } from "vuex";

export default {
  name: "housereview",
  data() {
    return {
      house: {},
      isModifyShow: false,
      modifyReview: Object,
    };
  },
  computed: {
    ...mapGetters(["reviews"]),
    ...mapState(["avg"]),
    ...mapState(["aptName", "sameList"]),
  },
  components: {
    ReviewWrite,
    Review,
    GradeFor,
  },
  created() {
    //    http.get(`/review/${this.$route.params.aptCode}`).then(({ data }) => {
    //   this.house = data;
    // });
    //this.getReviews();
    // this.aptCode = this.$route.query.aptCode;
    // // 도서 정보 얻기.
    // this.$store.dispatch("house", `/map/${this.aptCode}`);
    // // 도서평(댓글) 얻기.
    // this.$store.dispatch("getReviews", `/review/${this.aptCode}`);
  },
  methods: {
    //...mapActions(["getReviews"]),
    onModifyReview(review) {
      this.modifyReview = review;
      this.isModifyShow = true;
    },
    onModifyReviewCancel(isShow) {
      this.isModifyShow = isShow;
    },
    getReviews() {
      console.log("리뷰 조회" + this.$route.params.aptCode);
      this.getReviews(this.$route.params.aptCode);
    },
  },
};
</script>

<style>
.avgscore {
  text-align: left;
  border-radius: 5px;
  background-color: #d6e7fa;
  padding: 20px 20px;
  margin: 10px;
  font-weight: bold;
  font-size: 20px;
}
</style>

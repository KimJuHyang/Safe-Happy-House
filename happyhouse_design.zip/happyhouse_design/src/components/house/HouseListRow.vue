<template>
  <b-container>
    <b-row class="m-2" @click="getCovidRank">
      <div>
        <b-card style="width: 100%">
          <b-row>
            <b-col cols="9">
              <h4>{{ house.아파트 }}</h4>
              <p style="color: gray">
                {{ house.법정동 + house.지번 }} ( {{ house.도로명 }})
              </p>
            </b-col>
            <b-col cols="1">
              <button
                @click="clickLike"
                class="btn"
                style="background-color: pink"
                v-if="type == 'addonly'"
              >
                <b-icon :icon="icon" aria-hidden="true"></b-icon>
              </button>

              <button
                @click="clickLike"
                class="btn"
                style="background-color: pink"
                v-if="type == 'removeonly'"
              >
                <b-icon :icon="iconf" aria-hidden="true"></b-icon>
              </button>
            </b-col>
          </b-row>

          <b-card-text>
            <b-badge pill variant="primary">면적/층</b-badge>
            {{ house.층 }} 층, {{ house.전용면적 }}m<sup>2</sup> <br />

            <b-badge pill variant="info">건축일자</b-badge>
            {{ house.건축년도 }}

            <p>
              <b-badge pill variant="warning">최근거래금액</b-badge>
              {{ house.거래금액 }}
            </p>

            <div v-if="type == 'addonly'">
              <b-button
                @click="showReview"
                style="
                  background-color: #e1f2fd;
                  color: #346ff9;
                  border-color: white;
                "
              >
                리뷰 보기</b-button
              >
              <b-button
                @click="aptEtc"
                style="
                  background-color: #e0fdd2;
                  color: #28640c;
                  border-color: white;
                "
                >유사 아파트 보기</b-button
              >
            </div>
          </b-card-text>
        </b-card>
      </div>
    </b-row>
  </b-container>
</template>

<script>
import { mapActions, mapState } from "vuex";
export default {
  name: "HouseListRow",
  data() {
    return {
      isLike: false,
      icon: "bookmark-heart",
      iconf: "bookmark-heart-fill",
    };
  },
  computed: {
    ...mapState["house"],
  },
  props: {
    house: Object,
    type: String,
  },
  watch: {
    house: function () {
      this.icon = "bookmark-heart";
    },
  },
  methods: {
    ...mapActions([
      "detailHouse",
      "addLike",
      "getCovidList",
      "removeLike",
      "setCovidRank",
      "getReviews",
      "getAptEtc",
    ]),
    selectHouse() {
      this.icon = "bookmark-heart";
      this.detailHouse(this.house);
    },
    clickLike: function () {
      console.log("눌럿음");
      this.isLike = !this.isLike;

      this.check();
      this.isLike = false;
    },
    check() {
      if (this.isLike && this.type === "addonly") {
        console.log(this.house);
        alert("관심단지가 등록되었습니다.");
        //여기서 버튼 색상 바꿔주기
        this.icon = "bookmark-heart-fill";
        this.addLike(this.house);
        this.getCovidList(this.house);
      } else {
        this.icon = "bookmark-heart";
        this.removeLike(this.house);
      }
    },
    getCovidRank() {
      if (this.type == "removeonly") {
        alert("관심단지가 해제되었습니다.");
        //여기서 버튼 색상 바꿔주기
        this.icon = "bookmark-heart";
        this.setCovidRank(this.house.아파트);
      }
    },
    showReview() {
      console.log("리뷰 버튼");
      // this.detailHouse(this.house);
      this.isShow = true;
      this.getReviews(this.house);
    },
    aptEtc() {
      this.getAptEtc(this.house);
    },
  },
};
</script>

<style scoped src="@/assets/styles/style.css">
.apt {
  width: 50px;
}
.mouse-over-bgcolor {
  background-color: lightblue;
}
</style>

<template>
  <div>
    <div>
      <div class="main">
        <div class="responsive-wrapper" v-if="sameList.length != 0">
          <div class="content-header" style="padding-left: 25%">
            <div class="content-header-intro">
              <h2>{{ aptName }}과 유사한 아파트는?</h2>
              <p>
                평균 별점이 유사한 아파트를 추천합니다.

                <grade-for v-for="(avgi, index) in avg" :key="index" />
              </p>
            </div>
          </div>

          <div class="context text-center">
            <same-list
              v-for="(list, index) in sameList"
              :key="index"
              :no="`${index + 1}`"
              :list="list"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import SameList from "@/components/house/review/SameList.vue";
import { mapState } from "vuex";

export default {
  name: "housesamelist",
  data() {
    return {
      isShow: true,
    };
  },
  computed: {
    ...mapState(["sameList", "aptName", "apt"]),
  },
  components: {
    SameList,
  },
};
</script>

<style>
.listhead {
  font-weight: bold;
  font-size: 18px;
  margin: 10px;
}
.lined {
  font-weight: bold;
  color: gray;
}
</style>

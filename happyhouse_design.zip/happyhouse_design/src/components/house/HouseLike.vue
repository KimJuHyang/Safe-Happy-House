<template>
  <b-container
    v-if="likeList && likeList.length != 0"
    class="bv-example-row mt-3"
  >
    <house-list-row
      v-for="(like, index) in likeList"
      :key="index"
      :house="like"
      type="removeonly"
    />
  </b-container>
  <b-container v-else class="bv-example-row mt-3">
    <b-row>
      <b-col><b-alert show>주택 목록이 없습니다.</b-alert></b-col>
    </b-row>
  </b-container>
</template>

<script>
import HouseListRow from "@/components/house/HouseListRow.vue";
import { mapState } from "vuex";

export default {
  name: "HouseLike",
  components: {
    HouseListRow,
  },
  data() {
    return {};
  },
  computed: {
    ...mapState(["likeList"]),
  },
};
</script>

<style></style>

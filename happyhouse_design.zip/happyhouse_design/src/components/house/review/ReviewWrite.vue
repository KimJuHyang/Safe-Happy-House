<template>
  <div class="regist">
    <div v-if="this.modifyReview != null" class="regist_form">
      <link
        href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css"
        rel="stylesheet"
        integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ"
        crossorigin="anonymous"
      />

      <span
        class="task__tag task__tag--copyright"
        style="margin-right: 10px; font-size: 15px"
        >{{ userInfo.userid }}님의 <label>리뷰 수정하기</label></span
      >

      <span
        ><b-button variant="danger" @click="updateReviewCancel">
          취소
        </b-button></span
      >
      <span
        ><b-button
          style="margin-right: 10px"
          variant="primary"
          @click="updateReview"
        >
          등록
        </b-button></span
      >
      <div
        class="
          starrating
          risingstar
          d-flex
          justify-content-center
          flex-row-reverse
        "
      >
        <input
          type="radio"
          id="star5"
          name="grade"
          value="5"
          v-model.number="grade"
        /><label for="star5" title="5 star">5</label>
        <input
          type="radio"
          id="star4"
          name="grade"
          value="4"
          v-model.number="grade"
        /><label for="star4" title="4 star">4</label>
        <input
          type="radio"
          id="star3"
          name="grade"
          value="3"
          v-model.number="grade"
        /><label for="star3" title="3 star">3</label>
        <input
          type="radio"
          id="star2"
          name="grade"
          value="2"
          v-model.number="grade"
        /><label for="star2" title="2 star">2</label>
        <input
          type="radio"
          id="star1"
          name="grade"
          value="1"
          v-model.number="grade"
        /><label for="star1" title="1 star">1</label>
      </div>

      <textarea
        id="review"
        name="review"
        v-model="modifyReview.review"
        cols="35"
        rows="2"
      ></textarea>
    </div>
    <div v-else class="regist_form">
      <span
        class="task__tag task__tag--design"
        style="margin-right: 10px; font-size: 15px"
        >리뷰 남기기</span
      >

      <span
        ><b-button variant="primary" @click="registReview">
          등록
        </b-button></span
      >
      <div
        class="
          starrating
          risingstar
          d-flex
          justify-content-center
          flex-row-reverse
        "
      >
        <input
          type="radio"
          id="star52"
          name="grade2"
          value="5"
          v-model.number="grade"
        /><label for="star52" title="5 star">5</label>
        <input
          type="radio"
          id="star42"
          name="grade2"
          value="4"
          v-model.number="grade"
        /><label for="star42" title="4 star">4</label>
        <input
          type="radio"
          id="star32"
          name="grade2"
          value="3"
          v-model.number="grade"
        /><label for="star32" title="3 star">3</label>
        <input
          type="radio"
          id="star22"
          name="grade2"
          value="2"
          v-model.number="grade"
        /><label for="star22" title="2 star">2</label>
        <input
          type="radio"
          id="star12"
          name="grade2"
          value="1"
          v-model.number="grade"
        /><label for="star12" title="1 star">1</label>
      </div>
      <textarea
        id="review"
        name="review"
        v-model="review"
        cols="35"
        rows="2"
      ></textarea>
    </div>
  </div>
</template>

<script>
import http from "@/util/http-common";
import { mapState, mapMutations, mapActions } from "vuex";
import { getMember } from "@/api/member";
const memberStore = "memberStore";
export default {
  name: "reviewwrite",
  data() {
    return {
      // 차후 작성자 이름은 로그인 구현후 로그인한 사용자로 바꾼다.

      review: "",
      grade: 0,
    };
  },
  props: {
    aptName: { type: String },
    modifyReview: { type: Object },
  },
  computed: {
    ...mapState(memberStore, ["userInfo"]),
    ...mapState(["aptName", "aptdong", "aptjibun"]),
  },
  created() {
    getMember(
      this.$route.params.userid,
      ({ data }) => {
        this.userInfo = data;
      },
      (error) => {
        console.log(error);
      }
    );
  },
  methods: {
    ...mapMutations(memberStore, ["SET_USER_INFO"]),
    ...mapMutations(["SET_APTNAME"]),
    ...mapActions(["setReviewList"]),
    registReview() {
      http
        .post("/review", {
          userid: this.userInfo.userid,
          review: this.review,
          grade: this.grade,
          aptName: this.aptName,
        })
        .then(({ data }) => {
          let msg = "등록 처리시 문제가 발생했습니다.";
          if (data === "success") {
            msg = "등록이 완료되었습니다.";
          }

          alert(msg);

          // 작성글 지우기
          this.review = "";
          this.grade = "";

          const param = {
            grade: this.grade,
            aptName: this.aptName,
            aptdong: this.aptdong,
            aptjibun: this.aptjibun,
          };
          this.setReviewList(param);

          // 도서평(댓글) 얻기.
          this.$store.dispatch("getReviews", `${this.aptName}`);
        });
    },
    updateReview() {
      console.log(this.modifyReview.reviewno);
      http
        .put(`/review`, {
          reviewno: this.modifyReview.reviewno,
          review: this.modifyReview.review,
          grade: this.modifyReview.grade,
        })
        .then(({ data }) => {
          let msg = "수정 처리시 문제가 발생했습니다.";
          if (data === "success") {
            msg = "수정이 완료되었습니다.";
          }
          alert(msg);

          // 도서평(댓글) 얻기.
          this.$store.dispatch("getReviews", `${name}`);
        });
    },
    updateReviewCancel() {
      this.$emit("modify-review-cancel", false);
    },
  },
};
</script>

<style scoped>
.regist {
  padding: 10px;
}
.regist_form {
  text-align: left;
  border-radius: 5px;
  background-color: #f0f7ff;
  padding: 20px;
}

textarea {
  width: 90%;
  padding: 10px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  color: #787878;
  font-size: large;
}

button {
  float: right;
}

button.small {
  width: 60px;
  font-size: small;
  font-weight: bold;
}

/***
 *  Simple Pure CSS Star Rating Widget Bootstrap 4 
 * 
 *  www.TheMastercut.co
 *  
 ***/

@import url(//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css);

/* Styling h1 and links
––––––––––––––––––––––––––––––––– */
h1[alt="Simple"] {
  color: white;
}
a[href],
a[href]:hover {
  color: grey;
  font-size: 0.5em;
  text-decoration: none;
}

.starrating > input {
  display: none;
} /* Remove radio buttons */

.starrating > label:before {
  content: "\f005"; /* Star */
  margin: 2px;
  font-size: 2.5em;
  font-family: FontAwesome;
  display: inline-block;
}

.starrating > label {
  color: #b3b3b3; /* Start color when not clicked */
}

.starrating > input:checked ~ label {
  color: #ffca08;
} /* Set yellow color when star checked */

.starrating > input:hover ~ label {
  color: #ffca08;
} /* Set yellow color when star hover */
</style>

<template>
  <b-icon icon="star-fill" font-scale="1" variant="warning"></b-icon>
</template>

<script>
export default {
  name: "gradefor",
  data() {
    return {
      index: "",
    };
  },
  props: {
    grade: { type: Object },
  },
};
</script>

<style></style>

<template>
  <div v-show="isShow" class="comment">
    <div class="head">
      <div>
        <span
          class="task__tag task__tag--design"
          style="margin-right: 10px; font-size: 15px"
          >{{ review.reviewno }}번째 리뷰
        </span>
        {{ review.grade }}
        <grade-for v-for="(grade, index) in review.grade" :key="index" />
      </div>
      <br />
      <span
        class="task__tag task__tag--illustration"
        style="margin-right: 10px; font-size: 15px"
        >작성자
      </span>
      {{ review.userid }} ({{ review.reviewtime }})
    </div>
    <div class="content" v-html="enterToBr(review.review)"></div>
    <!-- 로그인 기능 구현 후 로그인한 자신의 글에만 보이게 한다. -->
    <div class="cbtn">
      <label @click="modifyReviewView">수정</label> |
      <label @click="deleteReview">삭제</label>
    </div>
  </div>
</template>

<script>
import http from "@/util/http-common";
import GradeFor from "@/components/house/review/GradeFor.vue";
export default {
  name: "review",
  data() {
    return {
      isShow: true,
    };
  },
  props: {
    review: Object,
  },
  components: {
    GradeFor,
  },
  methods: {
    modifyReviewView() {
      this.$emit("modify-review", {
        reviewno: this.review.reviewno,
        review: this.review.review,
        aptName: this.review.aptName,
      });
    },
    deleteReview() {
      if (confirm("정말로 삭제?")) {
        http.delete(`/review/${this.review.reviewno}`).then(({ data }) => {
          let msg = "삭제 처리시 문제가 발생했습니다.";
          if (data === "success") {
            msg = "삭제가 완료되었습니다.";
          }
          alert(msg);
          // 도서평(댓글) 얻기.
          this.$store.dispatch("getReviews", `${this.review.aptName}`);
        });
      }
    },
    enterToBr(str) {
      if (str) return str.replace(/(?:\r\n|\r|\n)/g, "<br />");
    },
  },
};
</script>

<style>
.comment {
  text-align: left;
  border-radius: 5px;
  background-color: #f0f7ff;
  padding: 10px 20px;
  margin: 10px;
}
.head {
  margin-bottom: 5px;
}
.content {
  padding: 5px;
}
.cbtn {
  text-align: right;
  color: steelblue;
  margin: 5px 0px;
}
</style>

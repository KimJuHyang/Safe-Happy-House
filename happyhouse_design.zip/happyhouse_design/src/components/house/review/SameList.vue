<template>
  <div v-show="isShow" class="comment">
    <div class="head">
      {{ no }}. {{ list.aptName }} ({{ list.aptdong }} -{{ list.aptjibun }})
    </div>
  </div>
</template>

<script>
export default {
  name: "samelist",
  data() {
    return {
      isShow: true,
    };
  },
  props: {
    list: Object,
    no: String,
  },
};
</script>

<style></style>

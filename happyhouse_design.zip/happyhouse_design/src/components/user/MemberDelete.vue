<template>
  <b-container class="bv-example-row mt-3">
    <b-row>
      <b-col>
        <b-alert show><h3>회원 탈퇴</h3></b-alert>
      </b-col>
    </b-row>
    <b-row>
      <b-col><b-alert show variant="danger">삭제처리중...</b-alert></b-col>
    </b-row>
  </b-container>
</template>

<script>
import http from "@/util/http-common";
//import memberStore from "./store/modules/memberStore";
//const memberStore = "memberStore";
export default {
  name: "MemberDelete",
  //  async beforeCreate() {
  //   let token = sessionStorage.getItem("access-token");
  //   if(memberStore.state.userInfo == null && token) {
  //     await memberStore.dispatch("getUserInfo", token);
  //   }
  // },
  created() {
    http.delete(`/user/${this.$route.params.userid}`).then(({ data }) => {
      let msg = "삭제 처리시 문제가 발생했습니다.";
      if (data === "success") {
        msg = "삭제가 완료되었습니다.";
        sessionStorage.removeItem("access-token");
        sessionStorage.clear();
      }
      alert(msg);
      // 현재 route를 /list로 변경.
      this.$router.push({ name: "House" });
    });
  },
};
</script>

<style></style>

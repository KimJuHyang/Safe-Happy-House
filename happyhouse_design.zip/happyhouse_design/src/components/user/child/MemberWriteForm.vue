<template>
  <form action="" @submit="onSubmit" @reset="onReset" class="signupForm">
    <h2 v-if="this.type === 'register'">Sign Up</h2>
    <h2 v-else>회원 수정</h2>

    <div class="idForm">
      <input
        type="text"
        class="id"
        id="userid"
        :disabled="isUserid"
        v-model="userInfo.userid"
        required
        placeholder="ID"
      />
    </div>
    <div class="passForm">
      <input
        type="password"
        class="pw"
        id="userpwd"
        v-model="userInfo.userpwd"
        required
        placeholder="PW"
      />
    </div>
    <div class="idForm">
      <input
        type="text"
        class="id"
        id="username"
        v-model="userInfo.username"
        required
        placeholder="USER NAME"
      />
    </div>
    <div class="idForm">
      <input
        type="email"
        class="id"
        id="email"
        v-model="userInfo.email"
        required
        placeholder="EMAIL"
      />
    </div>
    <div class="idForm">
      <input
        type="text"
        class="id"
        id="address"
        v-model="userInfo.address"
        required
        placeholder="ADDRESS"
      />
    </div>
    <button
      type="submit"
      class="g-actions-button22 g-actions-button22-default"
      v-if="this.type === 'register'"
    >
      SIGN UP
    </button>
    <button
      class="g-actions-button22 g-actions-button22-default"
      type="submit"
      v-else
    >
      회원수정
    </button>
    <button class="g-actions-button33 g-actions-button33-default" type="reset">
      reset
    </button>
  </form>
</template>

<script>
//import http from "@/util/http-common";
import { mapActions, mapMutations } from "vuex";
import { getMember, modifyMember, regMember } from "@/api/member";
const memberStore = "memberStore";
//const memberStore = "memberStore";

export default {
  name: "MemberWriteForm",
  data() {
    return {
      userInfo: {
        userid: "",
        username: "",
        userpwd: "",
        email: "",
        address: "",
      },
      isUserid: false,
    };
  },
  props: {
    type: { type: String },
  },
  created() {
    if (this.type === "modify") {
      getMember(
        this.$route.params.userid,
        ({ data }) => {
          // this.article.articleno = data.article.articleno;
          // this.article.userid = data.article.userid;
          // this.article.subject = data.article.subject;
          // this.article.content = data.article.content;
          this.userInfo = data;
        },
        (error) => {
          console.log(error);
        }
      );
      this.isUserid = true;
    }
  },
  methods: {
    ...mapActions(["setModify"]),
    ...mapMutations(memberStore, ["SET_IS_LOGIN", "SET_USER_INFO"]),
    onSubmit(event) {
      event.preventDefault();

      let err = true;
      let msg = "";
      !this.userInfo.userid &&
        ((msg = "아이디 입력해주세요"),
        (err = false),
        this.$refs.userid.focus());
      err &&
        !this.userInfo.username &&
        ((msg = "이름 입력해주세요"),
        (err = false),
        this.$refs.username.focus());
      err &&
        !this.userInfo.userpwd &&
        ((msg = "비밀번호 입력해주세요"),
        (err = false),
        this.$refs.userpwd.focus());
      err &&
        !this.userInfo.email &&
        ((msg = "이메일 입력해주세요"),
        (err = false),
        this.$refs.email.focus());
      err &&
        !this.userInfo.address &&
        ((msg = "주소 입력해주세요"),
        (err = false),
        this.$refs.address.focus());

      if (!err) alert(msg);
      else this.type === "register" ? this.registMember() : this.updateMember();
    },
    onReset(event) {
      event.preventDefault();
      this.userInfo.username = "";
      this.userInfo.userpwd = "";
      this.userInfo.email = "";
      this.userInfo.address = "";
      //this.$router.push({ name: "UserList" });
    },
    registMember() {
      regMember(
        {
          userid: this.userInfo.userid,
          username: this.userInfo.username,
          userpwd: this.userInfo.userpwd,
          email: this.userInfo.email,
          address: this.userInfo.address,
        },
        ({ data }) => {
          let msg = "등록 처리시 문제가 발생했습니다.";
          if (data === "success") {
            msg = "등록이 완료되었습니다.";
          }
          alert(msg);
          this.moveList();
        },
        (error) => {
          console.log(error);
        }
      );
    },
    async updateMember() {
      const params = {
        userid: this.userInfo.userid,
        username: this.userInfo.username,
        userpwd: this.userInfo.userpwd,
        email: this.userInfo.email,
        address: this.userInfo.address,
      };
      this.setModify(params);
      await modifyMember(
        {
          userid: this.userInfo.userid,
          username: this.userInfo.username,
          userpwd: this.userInfo.userpwd,
          email: this.userInfo.email,
          address: this.userInfo.address,
        },
        ({ data }) => {
          let msg = "수정 처리시 문제가 발생했습니다.";
          if (data === "success") {
            msg = "수정이 완료되었습니다.";
            this.SET_USER_INFO(this.userInfo);
          }
          alert(msg);
          // 현재 route를 /list로 변경.

          this.$router.push({
            name: "MyPage",
            params: { userid: this.userInfo.userid },
          });
        },
        (error) => {
          console.log(error);
        }
      );
    },
    moveList() {
      this.$router.push({ name: "House" });
    },
  },
};
</script>

<style>
* {
  margin: 0px;
  padding: 0px;
  text-decoration: none;
  font-family: sans-serif;
}

body {
  background-image: #34495e;
}

.signupForm {
  position: absolute;
  top: 80%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 350px;
  height: 610px;
  padding: 30px, 20px;
  background-color: #ffffff;
  text-align: center;
  border-radius: 10px;
  box-shadow: 5px 5px 5px 5px lightgray;
}
.signupForm h2 {
  text-align: center;
  margin: 30px;
}

.idForm {
  border-bottom: 2px solid #adadad;
  margin: 30px;
  padding: 10px 10px;
}

.passForm {
  border-bottom: 2px solid #adadad;
  margin: 30px;
  padding: 10px 10px;
}

.id {
  width: 100%;
  border: none;
  outline: none;
  color: #636e72;
  font-size: 16px;
  height: 25px;
  background: none;
}

.pw {
  width: 100%;
  border: none;
  outline: none;
  color: #636e72;
  font-size: 16px;
  height: 25px;
  background: none;
}

.btn4 {
  position: relative;
  left: 40%;
  transform: translateX(-50%);
  margin-bottom: 40px;
  width: 80%;
  height: 40px;
  background: linear-gradient(125deg, #81ecec, #6c5ce7, #81ecec);
  background-position: left;
  background-size: 200%;
  color: white;
  font-weight: bold;
  border: none;
  cursor: pointer;
  transition: 0.4s;
  display: inline;
}

.btn:hover {
  background-position: right;
}

.bottomText {
  text-align: center;
}
</style>

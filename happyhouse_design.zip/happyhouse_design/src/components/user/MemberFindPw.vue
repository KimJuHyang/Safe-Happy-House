<template>
  <form action="" class="loginForm2">
    <h2>Find Password</h2>
    <alert show variant="danger" class="alertuser" v-if="isLoginError"
      >아이디 또는 이메일을 확인하세요.</alert
    >
    <div class="idForm">
      <input
        type="text"
        class="id"
        id="userid"
        v-model="userInfo.userid"
        required
        placeholder="ID"
        @keyup.enter="changePwd"
      />
    </div>
    <div class="idForm">
      <input
        type="text"
        class="id"
        id="username"
        v-model="userInfo.username"
        required
        placeholder="NAME"
        @keyup.enter="changePwd"
      />
    </div>
    <div class="passForm">
      <input
        type="text"
        class="pw"
        id="email"
        v-model="userInfo.email"
        required
        placeholder="EMAIL"
        @keyup.enter="changePwd"
      />
    </div>
    <button type="button" class="btn4" @click="changePwd">FIND</button>
  </form>
</template>

<script>
import { pwd } from "@/api/member.js";
import { mapState, mapActions } from "vuex";

const memberStore = "memberStore";
export default {
  name: "MemberFindPw",
  data() {
    return {
      userInfo: {
        userid: null,
        email: null,
        username: null,
      },
    };
  },
  props: {
    type: { type: String },
  },
  computed: {
    ...mapState(memberStore, ["isLogin", "isLoginError"]),
  },
  methods: {
    ...mapActions(memberStore, ["userConfirm", "getUserInfo"]),
    async confirm() {},
    async changePwd() {
      pwd(
        {
          userid: this.userInfo.userid,
          email: this.userInfo.email,
          username: this.userInfo.username,
        },
        (this.userInfo.userid = ""),
        (this.userInfo.username = ""),
        (this.userInfo.email = ""),
        this.$router.push({ name: "SignIn" })
      );
    },
  },
};
</script>

<style>
* {
  margin: 0px;
  padding: 0px;
  text-decoration: none;
  font-family: sans-serif;
}

body {
  background-image: #34495e;
}

.loginForm2 {
  position: absolute;
  width: 350px;
  height: 400px;
  padding: 30px, 20px;
  background-color: #ffffff;
  text-align: center;
  top: 70%;
  left: 50%;
  transform: translate(-50%, -50%);
  border-radius: 10px;
  box-shadow: 5px 5px 5px 5px lightgray;
}

.loginForm2 h2 {
  text-align: center;
  margin: 30px;
}

.idForm {
  border-bottom: 2px solid #adadad;
  margin: 30px;
  padding: 10px 10px;
}

.passForm {
  border-bottom: 2px solid #adadad;
  margin: 30px;
  padding: 10px 10px;
}

.id {
  width: 100%;
  border: none;
  outline: none;
  color: #636e72;
  font-size: 16px;
  height: 25px;
  background: none;
}

.pw {
  width: 100%;
  border: none;
  outline: none;
  color: #636e72;
  font-size: 16px;
  height: 25px;
  background: none;
}

.btn4 {
  position: relative;
  left: 40%;
  transform: translateX(-50%);
  margin-bottom: 40px;
  width: 80%;
  height: 40px;
  background: linear-gradient(125deg, #81ecec, #6c5ce7, #81ecec);
  background-position: left;
  background-size: 200%;
  color: white;
  font-weight: bold;
  border: none;
  cursor: pointer;
  transition: 0.4s;
  display: inline;
}

.btn:hover {
  background-position: right;
}

.bottomText {
  text-align: center;
}
</style>

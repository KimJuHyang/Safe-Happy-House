<template>
  <form action="" class="loginForm">
    <h2>Login</h2>
    <alert show variant="danger" class="alertuser" v-if="isLoginError"
      >아이디 또는 비밀번호를 확인하세요.</alert
    >
    <div class="idForm">
      <input
        type="text"
        class="id"
        id="userid"
        v-model="user.userid"
        required
        placeholder="ID"
        @keyup.enter="confirm"
      />
    </div>
    <div class="passForm">
      <input
        type="password"
        class="pw"
        id="userpwd"
        v-model="user.userpwd"
        required
        placeholder="PW"
        @keyup.enter="confirm"
      />
    </div>
    <button type="button" class="btn4" @click="confirm">LOG IN</button>
    <div class="bottomText">
      Don't you have ID?
      <router-link :to="{ name: 'SignUp' }">sign up</router-link>
    </div>
    <div class="bottomText">
      <router-link :to="{ name: 'FindPw' }">Forgot your password?</router-link>
    </div>
  </form>
</template>

<script>
import { mapState, mapActions } from "vuex";

const memberStore = "memberStore";

export default {
  name: "MemberLogin",
  data() {
    return {
      user: {
        userid: null,
        userpwd: null,
      },
    };
  },
  computed: {
    ...mapState(memberStore, ["isLogin", "isLoginError"]),
  },
  methods: {
    ...mapActions(memberStore, ["userConfirm", "getUserInfo"]),
    async confirm() {
      await this.userConfirm(this.user);
      let token = sessionStorage.getItem("access-token");
      if (this.isLogin) {
        await this.getUserInfo(token);
        this.$router.push({ name: "House" });
      }
    },
    movePage() {
      this.$router.push({ name: "SignUp" });
    },
    movePage2() {
      this.$router.push({ name: "FindPw" });
    },
  },
};
</script>

<style>
* {
  margin: 0px;
  padding: 0px;
  text-decoration: none;
  font-family: sans-serif;
}

body {
  background-image: #34495e;
}

.loginForm {
  position: absolute;
  width: 350px;
  height: 480px;
  padding: 30px, 20px;
  background-color: #ffffff;
  text-align: center;
  top: 70%;
  left: 50%;
  transform: translate(-50%, -50%);
  border-radius: 10px;
  box-shadow: 5px 5px 5px 5px lightgray;
}

.loginForm h2 {
  text-align: center;
  margin: 30px;
}

.idForm {
  border-bottom: 2px solid #adadad;
  margin: 30px;
  padding: 10px 10px;
}

.passForm {
  border-bottom: 2px solid #adadad;
  margin: 30px;
  padding: 10px 10px;
}

.id {
  width: 100%;
  border: none;
  outline: none;
  color: #636e72;
  font-size: 16px;
  height: 25px;
  background: none;
}

.pw {
  width: 100%;
  border: none;
  outline: none;
  color: #636e72;
  font-size: 16px;
  height: 25px;
  background: none;
}

.btn4 {
  position: relative;
  left: 40%;
  transform: translateX(-50%);
  margin-bottom: 40px;
  width: 80%;
  height: 40px;
  background: linear-gradient(125deg, #81ecec, #6c5ce7, #81ecec);
  background-position: left;
  background-size: 200%;
  color: white;
  font-weight: bold;
  border: none;
  cursor: pointer;
  transition: 0.4s;
  display: inline;
}

.btn:hover {
  background-position: right;
}

.bottomText {
  text-align: center;
}
</style>

<template>
  <b-container class="mt-4">
    <b-row>
      <b-col>
        <b-alert variant="secondary" show><h3>내정보 수정</h3></b-alert>
      </b-col>
    </b-row>
    <member-write-form type="modify" />
  </b-container>
</template>

<script>
import MemberWriteForm from "./child/MemberWriteForm.vue";

export default {
  name: "MemberUpdate",
  components: {
    MemberWriteForm,
  },
};
</script>

<style></style>

<template>
  <b-container class="mt-4" v-if="userInfo">
    <div class="signupForm2">
      <h2>My Page</h2>
      <div class="idForm">ID : {{ userInfo.userid }}</div>
      <div class="idForm">NAME : {{ userInfo.username }}</div>
      <div class="idForm">EMAIL : {{ userInfo.email }}</div>
      <div class="idForm">ADDRESS : {{ userInfo.address }}</div>
      <div class="idForm">JOINDATE : {{ userInfo.joindate }}</div>

      <button
        type="button"
        class="g-actions-button22 g-actions-button22-default"
        @click="moveModifyMember"
      >
        정보 수정
      </button>
      <button
        type="button"
        class="g-actions-button33 g-actions-button33-default"
        @click="deleteMember"
      >
        회원 탈퇴
      </button>
    </div>
  </b-container>
</template>

<script>
//import http from "@/util/http-common";
import { mapState, mapActions, mapMutations } from "vuex";
import http from "@/util/http-common";
const memberStore = "memberStore";

export default {
  name: "MemberMyPage",
  data() {
    return {
      //     userInfo: {
      userid: this.userInfo.userid,
      //       username:null,
      //       email:null,
      //       address:null,
      //     },
    };
  },
  components: {},
  watch: {
    userInfo: function () {
      this.SET_USER_INFO(this.userInfo);
      console.log("change");
    },
  },
  computed: {
    ...mapState(memberStore, ["userInfo", "isLogin", "isLoginError"]),
  },
  created() {
    console.log("userid내나");
    console.log(this.$route.params.userid);
    let userid = this.$route.params.userid;
    // if(!userid){
    //   userid = this.userInfo.userid;
    // }
    http.get(`/user/${userid}`).then(({ data }) => {
      this.userInfo = data;
      this.getUserInfo(data);
    });

    console.log(memberStore);
    console.log(this.userInfo);
  },
  methods: {
    ...mapActions(memberStore, ["userConfirm", "getUserInfo"]),
    ...mapMutations(memberStore, ["SET_IS_LOGIN", "SET_USER_INFO"]),
    moveModifyMember() {
      this.$router.replace({
        name: "MyPageUpdate",
        params: { userid: this.userInfo.userid },
      });
      //   this.$router.push({ path: `/board/modify/${this.article.articleno}` });
    },
    deleteMember() {
      if (confirm("정말로 삭제?")) {
        http.delete(`/user/${this.userInfo.userid}`).then(({ data }) => {
          let msg = "삭제 처리시 문제가 발생했습니다.";
          if (data === "success") {
            this.userInfo = null;
            this.SET_IS_LOGIN(false);
            this.SET_USER_INFO(null);
            msg = "삭제가 완료되었습니다.";
            sessionStorage.removeItem("access-token");
            sessionStorage.clear();
          }
          alert(msg);
          // 현재 route를 /list로 변경.
          this.userInfo = null;
          this.SET_IS_LOGIN(false);
          this.SET_USER_INFO(null);
          this.$router.push({ name: "House" });
        });
        // this.$router.replace({
        //   name: "MemberDelete",
        //   params: { userid: this.userInfo.userid },
        // });
      }
    },
  },
};
</script>

<style>
* {
  margin: 0px;
  padding: 0px;
  text-decoration: none;
  font-family: sans-serif;
}

body {
  background-image: #34495e;
}

.signupForm2 {
  position: absolute;
  top: 80%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 480px;
  height: 510px;
  padding: 30px, 20px;
  background-color: #ffffff;
  text-align: center;
  border-radius: 10px;
  box-shadow: 5px 5px 5px 5px lightgray;
}
.signupForm h2 {
  text-align: center;
  margin: 30px;
}

.idForm {
  border-bottom: 2px solid #adadad;
  margin: 30px;
  padding: 10px 10px;
}

.passForm {
  border-bottom: 2px solid #adadad;
  margin: 30px;
  padding: 10px 10px;
}

.id {
  width: 100%;
  border: none;
  outline: none;
  color: #636e72;
  font-size: 16px;
  height: 25px;
  background: none;
}

.pw {
  width: 100%;
  border: none;
  outline: none;
  color: #636e72;
  font-size: 16px;
  height: 25px;
  background: none;
}

.btn4 {
  position: relative;
  left: 40%;
  transform: translateX(-50%);
  margin-bottom: 40px;
  width: 80%;
  height: 40px;
  background: linear-gradient(125deg, #81ecec, #6c5ce7, #81ecec);
  background-position: left;
  background-size: 200%;
  color: white;
  font-weight: bold;
  border: none;
  cursor: pointer;
  transition: 0.4s;
  display: inline;
}

.btn:hover {
  background-position: right;
}

.bottomText {
  text-align: center;
}
</style>

<template>
  <b-container class="bv-example-row mt-3">
    <member-write-form type="register" />
  </b-container>
</template>

<script>
import MemberWriteForm from "./child/MemberWriteForm.vue";

export default {
  name: "MemberJoin",
  components: {
    MemberWriteForm,
  },
};
</script>

<style></style>

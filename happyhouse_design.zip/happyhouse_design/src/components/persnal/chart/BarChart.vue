<script>
//Importing Bar class from the vue-chartjs wrapper
import { Bar } from "vue-chartjs";
//Exporting this so it can be used in other components
export default {
  extends: Bar,
  props: ["mydata", "loc"],
  watch: {
    mydata: function () {
      let datacollection = {
        //Data to be represented on x-axis
        labels: ["전국", this.loc],
        datasets: [
          {
            label: "전국",
            backgroundColor: "#FEF5ED",
            pointBackgroundColor: "white",
            borderWidth: 1,
            pointBorderColor: "#249EBF",
            //Data to be represented on y-axis
            // data: [40, 20, 30, 50, 90, 10, 20],
            data: [this.mydata[0]],
          },
          {
            label: this.loc,
            backgroundColor: "#D3E4CD",
            pointBackgroundColor: "black",
            borderWidth: 1,
            pointBorderColor: "#249EBF",
            //Data to be represented on y-axis
            // data: [40, 20, 30, 50, 90, 10, 20],
            data: [this.mydata[1]],
          },
        ],
      };
      //Chart.js options that controls the appearance of the chart
      let options = {
        scales: {
          yAxes: [
            {
              ticks: {
                beginAtZero: true,
              },
              gridLines: {
                display: true,
              },
            },
          ],
          xAxes: [
            {
              gridLines: {
                display: false,
              },
            },
          ],
        },
        legend: {
          display: true,
        },
        responsive: true,
        maintainAspectRatio: false,
      };

      this.renderChart(datacollection, options);
    },
  },
  data() {
    return {};
  },
  mounted() {
    //renderChart function renders the chart with the datacollection and options object.
    //this.renderChart(this.datacollection, this.options);
  },
};
</script>

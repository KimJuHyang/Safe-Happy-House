<template>
  <div>
    <div class="content-header">
      <div class="content-header-intro">
        <h2>지금 신고하면 언제 올까?</h2>
        <p>
          실시간 도로 상황을 기반으로 맞춤 주택까지의 경찰서/소방서 도착
          소요시간을 예측합니다.
        </p>
      </div>
    </div>
    <div class="context text-center">
      <h3>
        실시간 교통 상황 Live
        <b-icon
          icon="circle-fill"
          animation="fade"
          font-scale="1"
          variant="danger"
        ></b-icon>
      </h3>
    </div>
    <div class="content text-center">
      <article class="card">
        <div
          class="card-header"
          style="background-color: #2277f8; color: white"
        >
          <div>
            <span
              ><img src="https://assets.codepen.io/285131/zeplin.svg"
            /></span>
            <h4>112</h4>
          </div>
        </div>
        <div class="card-body">
          <div v-for="(list, index) in policeList" :key="index">
            <div style="margin-bottom: 30px">
              <div
                style="margin-bottom: 10px"
                v-if="transPoliceList[index] != null"
              >
                <span
                  class="task__tag task__tag--danger"
                  v-if="transPoliceList[index].speed <= 20"
                >
                  혼잡
                </span>
                <span
                  class="task__tag task__tag--nomal"
                  v-else-if="transPoliceList[index].speed <= 30"
                >
                  보통</span
                >

                <span class="task__tag task__tag--illustration">원활</span>
              </div>
              <div v-else>
                <span class="task__tag task__tag--illustration">원활</span>
              </div>
              <br />
              <span class="task__tag task__tag--copyright">{{ list.apt }}</span>

              <span v-if="transPoliceList[index] != null">
                <span v-if="transPoliceList[index].speed <= 20">
                  <!-- {{ transPoliceList[index].roadName }} -->
                  -------------
                  <span class="task__tag task__tag--danger">
                    소요시간 약 {{ list.time + 5 }} 분
                  </span>
                  -------------
                </span>
                <span v-else-if="transPoliceList[index].speed <= 30">
                  -------------
                  <span class="task__tag task__tag--nomal">
                    소요시간 약 {{ list.time + 2 }} 분
                  </span>
                  -------------
                </span>
                <span v-else>
                  -------------
                  <span class="task__tag task__tag--illustration">
                    소요시간 약 {{ list.time }} 분
                  </span>
                  -------------
                </span>
              </span>
              <span v-else>
                -------------
                <span class="task__tag task__tag--illustration">
                  소요시간 약 {{ list.time }} 분
                </span>
                -------------
              </span>

              <span class="task__tag task__tag--design">{{ list.target }}</span>
              <br />
              <br />
              <img src="@/assets/112.png" />
            </div>
          </div>
        </div>
      </article>
      <article class="card">
        <div
          class="card-header"
          style="background-color: #ed4122; color: white"
        >
          <div>
            <span
              ><img src="https://assets.codepen.io/285131/zeplin.svg"
            /></span>
            <h4>119</h4>
          </div>
          <label class="toggle"> 갱신주기 : 5분 </label>
        </div>
        <div class="card-body">
          <div v-for="(list, index) in fireList" :key="index">
            <div style="margin-bottom: 30px">
              <div
                style="margin-bottom: 10px"
                v-if="transPoliceList[index] != null"
              >
                <span
                  class="task__tag task__tag--danger"
                  v-if="transPoliceList[index].speed <= 20"
                >
                  혼잡
                </span>
                <span
                  class="task__tag task__tag--nomal"
                  v-else-if="transPoliceList[index].speed <= 30"
                >
                  보통</span
                >

                <span v-else class="task__tag task__tag--illustration"
                  >원활</span
                >
              </div>
              <div v-else>
                <span class="task__tag task__tag--illustration">원활</span>
              </div>
              <br />
              <span class="task__tag task__tag--copyright">{{ list.apt }}</span>

              <span v-if="transPoliceList[index] != null">
                <span v-if="transPoliceList[index].speed <= 25">
                  <!-- {{ transPoliceList[index].roadName }} -->
                  -------------
                  <span class="task__tag task__tag--danger">
                    소요시간 약 {{ list.time + 5 }} 분
                  </span>
                  -------------
                </span>
                <span v-else-if="transPoliceList[index].speed <= 35">
                  -------------
                  <span class="task__tag task__tag--nomal">
                    소요시간 약 {{ list.time + 2 }} 분
                  </span>
                  -------------
                </span>
                <span v-else>
                  -------------
                  <span class="task__tag task__tag--illustration">
                    소요시간 약 {{ list.time }} 분
                  </span>
                  -------------
                </span>
              </span>
              <span v-else>
                -------------
                <span class="task__tag task__tag--illustration">
                  소요시간 약 {{ list.time }} 분
                </span>
                -------------
              </span>

              <span class="task__tag task__tag--design">{{ list.target }}</span>
              <br />
              <br />
              <img src="@/assets/119.png" />
            </div>
          </div>
        </div>
      </article>
    </div>
  </div>
</template>

<script>
import { mapActions, mapState } from "vuex";
//import http from "@/util/http-common.js";
export default {
  computed: {
    ...mapState([
      "totalCountList",
      "persnalType",
      "policeList",
      "fireList",
      "persnal",
      "isTest",
      "transPoliceList",
      "transFireList",
    ]),
  },
  methods: {
    ...mapActions(["getTransTimePolice", "getTransTimeFire"]),
    setPlace() {
      let params1 = [];
      let params2 = [];

      this.policeList.forEach((police) => {
        console.log("호출");
        let maxX = null;
        let maxY = null;
        let minX = null;
        let minY = null;

        if (police.lon1 >= police.lon2) {
          maxX = police.lon1;
          minX = police.lon2;
        } else {
          maxX = police.lon2;
          minX = police.lon1;
        }

        if (police.lat1 >= police.lat2) {
          maxY = police.lat1;
          minY = police.lat2;
        } else {
          maxY = police.lat2;
          minY = police.lat1;
        }

        params1.push({
          minX: minX,
          maxX: maxX,
          minY: minY,
          maxY: maxY,
        });
      });

      this.fireList.forEach((fire) => {
        console.log("호출");
        let maxX = null;
        let maxY = null;
        let minX = null;
        let minY = null;

        if (fire.lon1 >= fire.lon2) {
          maxX = fire.lon1;
          minX = fire.lon2;
        } else {
          maxX = fire.lon2;
          minX = fire.lon1;
        }

        if (fire.lat1 >= fire.lat2) {
          maxY = fire.lat1;
          minY = fire.lat2;
        } else {
          maxY = fire.lat2;
          minY = fire.lat1;
        }

        params2.push({
          minX: minX,
          maxX: maxX,
          minY: minY,
          maxY: maxY,
        });
      });

      if (params1.length == 3) {
        params1.forEach((element) => {
          let data = {
            // apiKey: "a6ef10eb76e64e699e3ab12dc5ce6012",
            // type: "all",
            min1: element.minX,
            max1: element.maxX,
            min2: element.minY,
            max2: element.maxY,
            // getType: "json",
          };
          this.getTransTimePolice(data);
        });
      }

      params2.forEach((element) => {
        let data = {
          // apiKey: "a6ef10eb76e64e699e3ab12dc5ce6012",
          // type: "all",
          min1: element.minX,
          max1: element.maxX,
          min2: element.minY,
          max2: element.maxY,
          // getType: "json",
        };
        this.getTransTimeFire(data);
      });
    },
  },
};
</script>

<style></style>

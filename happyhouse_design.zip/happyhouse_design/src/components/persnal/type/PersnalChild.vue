<template>
  <div>
    <div class="content-header">
      <div class="content-header-intro">
        <h2>{{ persnal }}의 범죄 현황</h2>
        <p>
          아이가 있는 집은 특히 범죄에 주의해야합니다. <br />
          2021년 전국의 살인, 강도, 성폭력 발생건 평균과 {{ persnal }}의 평균을
          비교합니다.
        </p>
      </div>
    </div>
    <div class="context text-center">
      <!-- <div v-if="test.length != 0"> -->
      <b-row>
        <b-col>
          <span class="task__tag task__tag--design">살인 {{ test[1] }}건</span>
          <bar-chart
            v-bind:mydata="test"
            v-bind:loc="persnal"
            style="margin-top: 30px"
          ></bar-chart>
        </b-col>
        <b-col>
          <span class="task__tag task__tag--copyright"
            >강도 {{ test2[1] }}건</span
          ><bar-chart
            v-bind:mydata="test2"
            v-bind:loc="persnal"
            style="margin-top: 30px"
          ></bar-chart
        ></b-col>
        <b-col
          ><span class="task__tag task__tag--nomal"
            >성폭력 {{ test3[1] }}건</span
          ><bar-chart
            v-bind:mydata="test3"
            v-bind:loc="persnal"
            style="margin-top: 30px"
          ></bar-chart>
        </b-col>
      </b-row>

      <div v-if="test[1] > test[0]">
        <span class="task__tag task__tag--danger"
          >살인 건수가 평균보다 높은 지역입니다. 주의가 필요합니다.</span
        >
      </div>
      <br />
      <div v-if="test2[1] > test[0]">
        <span class="task__tag task__tag--danger"
          >강도 건수가 평균보다 높은 지역입니다. 주의가 필요합니다.</span
        >
      </div>
      <br />
      <div v-if="test3[1] > test[0]">
        <span class="task__tag task__tag--danger"
          >성폭력 건수가 평균보다 높은 지역입니다. 주의가 필요합니다.</span
        >
      </div>
      <br />
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";
import http from "@/util/http-common.js";
import BarChart from "@/components/persnal/chart/BarChart.vue";

//import CovidView from "@/components/covid/CovidView.vue";
export default {
  components: { BarChart },
  data() {
    return {
      murder: [],
      burglar: [],
      sexual: [],
      murder_avg: 0,
      burglar_avg: 0,
      sexual_avg: 0,
      thisMurder: 0,
      thisBurglar: 0,
      thisSexual: 0,
    };
  },
  computed: {
    ...mapState(["crimeList", "persnalType", "totalCountList", "persnal"]),

    test: function () {
      let crime = [];

      // 이부분 지방일때도 구현하기. (서울/인천/경기가 아니면으로 ?)
      let temp = this.persnal.split(" ");
      let str =
        temp[0].substring(0, 2) +
        "_" +
        (temp[1].length >= 3 ? temp[1].replace("구", "") : temp[1]);

      for (let key in this.murder) {
        if (key === str) {
          crime.push(this.murder_avg);
          crime.push(this.murder[key]);
        }
      }
      return crime;
    },

    test2: function () {
      let crime = [];

      // 이부분 지방일때도 구현하기. (서울/인천/경기가 아니면으로 ?)
      let temp = this.persnal.split(" ");
      let str =
        temp[0].substring(0, 2) +
        "_" +
        (temp[1].length >= 3 ? temp[1].replace("구", "") : temp[1]);

      for (let key in this.burglar) {
        if (key === str) {
          crime.push(this.burglar_avg);
          crime.push(this.burglar[key]);
        }
      }
      return crime;
    },

    test3: function () {
      let crime = [];

      // 이부분 지방일때도 구현하기. (서울/인천/경기가 아니면으로 ?)
      let temp = this.persnal.split(" ");
      let str =
        temp[0].substring(0, 2) +
        "_" +
        (temp[1].length >= 3 ? temp[1].replace("구", "") : temp[1]);
      for (let key in this.sexual) {
        if (key === str) {
          crime.push(this.sexual_avg);
          crime.push(this.sexual[key]);
        }
      }
      return crime;
    },
  },

  mounted() {
    const SERVICE_KEY = process.env.VUE_APP_APT_DEAL_API_KEY;
    const SERVICE_URL =
      "https://api.odcloud.kr/api/15085726/v1/uddi:66542ecf-c470-4c09-80df-a08348e9e679";
    const params = {
      serviceKey: decodeURIComponent(SERVICE_KEY), //여기서 페이징 처리, 년도도 만들어놓으면 댐
    };
    http
      .get(SERVICE_URL, { params })
      .then((response) => {
        //6-살인 9-성폭력 7-강도
        this.murder = response.data.data[6];
        this.burglar = response.data.data[7];
        this.sexual = response.data.data[9];

        var murder_sum = 0;
        let murder_cnt = 0;
        let burglar_sum = 0;
        let burglar_cnt = 0;
        let sexual_sum = 0;
        let sexual_cnt = 0;

        for (let key in this.murder) {
          //murder_sum += parseInt(this.murder[key]);
          if (!isNaN(this.murder[key] * 1)) {
            murder_sum += this.murder[key];
          }
          murder_cnt++;
        }
        for (let key in this.burglar) {
          if (!isNaN(this.burglar[key] * 1)) {
            burglar_sum += this.burglar[key];
          }
          burglar_cnt++;
        }
        for (let key in this.sexual) {
          if (!isNaN(this.sexual[key] * 1)) {
            sexual_sum += this.sexual[key];
          }
          sexual_cnt++;
        }

        this.murder_avg = Math.round(murder_sum / murder_cnt);
        this.burglar_avg = Math.round(burglar_sum / burglar_cnt);
        this.sexual_avg = Math.round(sexual_sum / sexual_cnt);
      })
      .catch();
  },
  methods: {},
};
</script>

<style lang="scss">
body {
  font-family: "Roboto";
  -webkit-font-smoothing: antialiased;
}

.bg-green {
  background: #1bc98e;
}

.bg-red {
  background: #e64759;
}

.bg-purple {
  background: #9f86ff;
}

.divide:before {
  background: rgba(0, 0, 0, 0.1);
  content: "";
  height: 1px;
  left: 0;
  position: absolute;
  right: 0;
  top: 8px;
  width: 100%;
  z-index: -1;
}
</style>

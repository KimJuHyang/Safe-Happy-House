<template>
  <div>
    <div class="content-header">
      <div class="content-header-intro">
        <h2>안하면 벌금! 반려동물 등록 대행 기관 목록</h2>
        <p>
          21년 9월 이후로 반려동물 등록을 안할 시 벌금이 부과됩니다.<br />
          {{ persnal }}에 있는 등록 대행 기관을 안내합니다.
        </p>
      </div>
    </div>
    <div class="context text-center">
      <div class="card-grid">
        <div v-for="(list, index) in test" :key="index">
          <article class="card">
            <div class="card-header">
              <div>
                <span style="margin-right: 10px"
                  ><img src="@/assets/pet.png" />
                </span>
                <h5>
                  {{ list.orgNm }}
                </h5>
              </div>
            </div>
            <div class="card-body">
              <p>
                <span
                  class="task__tag task__tag--nomal"
                  style="margin-right: 10px"
                  >주소</span
                >{{ list.orgAddr }}

                {{ list.orgAddrDtl }}
              </p>
              <p>
                <span
                  class="task__tag task__tag--copyright"
                  style="margin-right: 10px"
                  >담당자</span
                >
                {{ list.memberNm }}
              </p>
            </div>
            <div class="card-footer">
              <span
                class="task__tag task__tag--illustration"
                style="margin-right: 10px"
                >Tel</span
              >{{ list.tel }}
            </div>
          </article>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import http from "@/util/http-common.js";
import { mapState } from "vuex";
export default {
  computed: {
    ...mapState([
      "persnal",
      "totalCountList",
      "persnalType",
      "mysido",
      "mygugun",
      "myType",
    ]),

    test: function () {
      let place = [];
      if (this.persnalType == 4) {
        let persnal = this.persnal.split(" ");
        let sido = persnal[0];
        let gugun = persnal[1];

        this.placeList.forEach((element) => {
          if (element.orgAddr.includes(sido)) {
            if (element.orgAddr.includes(gugun)) {
              place.push(element);
            }
          }
        });
      }
      return place;
    },
  },
  data() {
    return {
      placeList: [],
      myplace: [],
      types: null,
    };
  },
  mounted() {
    const SERVICE_KEY = process.env.VUE_APP_APT_DEAL_API_KEY;
    const SERVICE_URL =
      "http://openapi.animal.go.kr/openapi/service/rest/recordAgencySrvc/recordAgency";
    const params = {
      serviceKey: decodeURIComponent(SERVICE_KEY), //여기서 페이징 처리, 년도도 만들어놓으면 댐
      pageNo: 1,
      numOfRows: 4200,
    };
    http
      .get(SERVICE_URL, { params })
      .then((response) => {
        //console.log(response.data.response.body.items);
        this.placeList = response.data.response.body.items.item;
        console.log(this.placeList);
      })
      .catch();
  },
  methods: {
    setAnimal() {},
  },
};
</script>

<style></style>

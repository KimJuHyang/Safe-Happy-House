<template>
  <div>
    <div class="content-header">
      <div class="content-header-intro">
        <h2>장애물 없는 생활환경 (Barrier Free) 인증 시설 정보</h2>
        <p>
          BF 인증이란, 장애인이 해당 시설을 접근/이용/이동함에 있어 불편을
          느끼지 않도록 시공 및 관리 되있다는 것을 인증합니다. <br />
          BF 인증을 받은 {{ persnal }} 시설을 안내합니다.
        </p>
      </div>
    </div>
    <div class="context text-center">
      <div class="card-grid">
        <div v-for="(list, index) in test" :key="index">
          <article class="card">
            <div
              class="card-header"
              style="background-color: #e6fbcd; color: #559705"
            >
              <div>
                <h5>{{ list.시설물명 }}</h5>
              </div>
              <label class="toggle">
                {{ list.등급 }}
                <div>***</div>
              </label>
            </div>
            <div class="card-body">
              <p>
                <span
                  class="task__tag task__tag--nomal"
                  style="margin-right: 10px"
                  >인증번호</span
                >{{ list.인증번호 }}
              </p>
              <p>
                <span
                  class="task__tag task__tag--design"
                  style="margin-right: 10px"
                  >발급일자</span
                >{{ list.발급일자 }}
              </p>
              <p>
                <span
                  class="task__tag task__tag--danger"
                  style="margin-right: 10px"
                  >주소</span
                >{{ list.지역코드 }}{{ list.시군구 }}
              </p>
            </div>
          </article>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import http from "@/util/http-common.js";
import { mapState } from "vuex";
export default {
  computed: {
    ...mapState([
      "persnal",
      "totalCountList",
      "persnalType",
      "mysido",
      "mygugun",
      "myType",
    ]),

    test: function () {
      let place = [];
      let persnal = this.persnal.split(" ");
      let sido = persnal[0];
      let gugun = persnal[1];

      this.placeList.forEach((element) => {
        if (element.지역코드 == sido && element.시군구 == gugun) {
          place.push(element);
        }
      });
      return place;
    },
  },
  data() {
    return {
      placeList: [],
      myplace: [],
    };
  },
  mounted() {
    const SERVICE_KEY = process.env.VUE_APP_APT_DEAL_API_KEY;
    const SERVICE_URL =
      "https://api.odcloud.kr/api/15014781/v1/uddi:c2477322-f2b1-4197-babe-a47ebb2924b8";
    const params = {
      serviceKey: decodeURIComponent(SERVICE_KEY), //여기서 페이징 처리, 년도도 만들어놓으면 댐
      page: 1,
      perPage: 1000,
    };
    http
      .get(SERVICE_URL, { params })
      .then((response) => {
        //console.log(response.data.response.body.items);
        console.log(response.data.data);
        this.placeList = response.data.data;
      })
      .catch();
  },
  methods: {},
};
</script>

<style></style>

<template>
  <b-row>
    <b-col cols="12" align="left">
      <b-row class="mt-4 mb-4 text-center">
        <b-col class="sm-3">
          <b-form-select
            v-model="sidoCode"
            :options="sidos"
            @change="gugunList"
          ></b-form-select>
        </b-col>

        <b-col class="sm-3">
          <b-form-select
            v-model="gugunCode"
            :options="guguns"
            @change="searchApt"
          ></b-form-select>
        </b-col>

        <b-col class="sm-3">
          <b-form-select
            v-model="selected"
            :options="persnalType"
            @change="initdMap"
          ></b-form-select>
        </b-col>
      </b-row>
    </b-col>
  </b-row>
</template>

<script>
import { mapState, mapActions, mapMutations } from "vuex";

export default {
  name: "PersnalSelectBar",
  data() {
    return {
      sidoCode: null,
      gugunCode: null,
      selected: null,
      sidoName: null,
      gugunName: null,
      persnalType: [
        { value: null, text: "거주 유형 선택" },
        { value: 1, text: "어린이" },
        { value: 2, text: "노인" },
        { value: 3, text: "장애인" },
        { value: 4, text: "반려동물" },
      ],
    };
  },
  computed: {
    // sidos() {
    //   return this.$store.state.sidos;
    // },
    ...mapState(["sidos", "guguns", "houses"]),
  },
  created() {
    //const API_KEY = "UfJp%2BQHEkAEmCuinTz78wJt%2BXLnjFAuy%2FYcdQhs%2FHzeu0JztltZmRBr01zrh6ZCuUwAyGB2SIFqXWLpTSK485w%3D%3D",
    //const URL =  "" <<api
    // this.$store.dispatch("getSido");
    this.sidoList();
  },
  methods: {
    ...mapActions([
      "getSido",
      "getGugun",
      "getHouseList",
      "saveThisGugun",
      "getPersnalMap",
      "setSidoName",
      "setGugunName",
      "clearType",
      "setType",
    ]),
    ...mapMutations(["CLEAR_SIDO_LIST", "CLEAR_GUGUN_LIST", "CLEAR_MYTYPE"]),
    sidoList() {
      this.CLEAR_SIDO_LIST();
      this.getSido();
    },
    gugunList() {
      this.CLEAR_GUGUN_LIST();
      this.gugunCode = null;
      if (this.sidoCode) {
        this.getGugun(this.sidoCode);
      }
      //시도 설정
    },
    searchApt() {
      this.CLEAR_MYTYPE();
      this.selected = null;
      if (this.gugunCode) {
        //여기서 타입값이랑 아예 같이 넘겨줘야함
        this.getHouseList(this.gugunCode);
      }
      //구군 설정 및 타입 클리어
    },
    initdMap() {
      //모든 애들 on, off 걸어주기. 타입별로.f

      this.setType(this.selected);

      this.sidos.forEach((sido) => {
        if (sido.value == this.sidoCode) {
          this.sidoName = sido.text;
        }
      });
      this.setSidoName(this.sidoName);

      this.guguns.forEach((gugun) => {
        if (gugun.value === this.gugunCode) {
          this.gugunName = gugun.text;
        }
      });
      this.setGugunName(this.gugunName);

      var params = {
        location: this.sidoName + " " + this.gugunName,
        type: this.selected,
      };

      this.getPersnalMap(params);
      this.CLEAR_MYTYPE();
    },
  },
};
</script>

<style></style>

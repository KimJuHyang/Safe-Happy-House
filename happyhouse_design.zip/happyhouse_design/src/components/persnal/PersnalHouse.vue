<template>
  <b-container
    v-if="totalCountList && totalCountList.length != 0"
    class="bv-example-row context text-center"
  >
    <div style="float: right; color: gray">
      <div v-if="persnalType == 1">
        <b-icon icon="exclamation-circle-fill" variant="secondary"></b-icon>
        직선거리 2km 이내 '어린이집, 키즈카페, 소아과, 놀이터' 의 개수를
        합산하여 선정합니다.
      </div>
      <div v-else-if="persnalType == 2">
        <b-icon icon="exclamation-circle-fill" variant="secondary"></b-icon>
        직선거리 2km 이내 '경찰서, 소방서, 노인복지센터' 의 개수를 합산하여
        선정합니다.
      </div>
      <div v-else-if="persnalType == 3">
        <b-icon icon="exclamation-circle-fill" variant="secondary"></b-icon>
        직선거리 2km 이내 '장애인 복지센터, 특수학교' 의 개수를 합산하여
        선정합니다.
      </div>
      <div v-else-if="persnalType == 4">
        <b-icon icon="exclamation-circle-fill" variant="secondary"></b-icon>
        직선거리 2km 이내 '동물병원, 공원(산책로), 애견카페' 의 개수를 합산하여
        선정합니다.
      </div>
    </div>
    <div>
      <img
        src="@/assets/rank_123.png"
        class="d-inline-block align-middle"
        width="80%"
        alt="Kitten"
      />
    </div>

    <b-row class="m-2">
      <b-col>
        <div>
          <b-card style="width: 100%">
            <h5 style="color: gray">
              <b-icon
                icon="exclamation-circle-fill"
                variant="secondary"
              ></b-icon>
              추천 시설 총
              <b-badge style="background-color: #f6a7c5">{{
                totalCountList[1].cnt
              }}</b-badge>
              개
            </h5>
            <h4>{{ totalCountList[1].아파트 }}</h4>
            <p style="color: gray">
              {{ totalCountList[1].법정동 + totalCountList[1].지번 }} (
              {{ totalCountList[1].도로명 }})
            </p>

            <b-card-text>
              <b-badge pill variant="primary">면적/층</b-badge>
              {{ totalCountList[1].층 }} 층,
              {{ totalCountList[1].전용면적 }}m<sup>2</sup>
              <br />

              <b-badge pill variant="info">건축일자</b-badge>
              {{ totalCountList[1].건축년도 }}

              <p>
                <b-badge pill variant="warning">최근거래금액</b-badge>
                {{ totalCountList[1].거래금액 }}
              </p>
            </b-card-text>
          </b-card>
        </div>
      </b-col>
      <b-col>
        <div>
          <b-card style="width: 100%">
            <h5 style="color: gray">
              <b-icon
                icon="exclamation-circle-fill"
                variant="secondary"
              ></b-icon>
              추천 시설 총
              <b-badge style="background-color: #f6a7c5">{{
                totalCountList[0].cnt
              }}</b-badge>
              개
            </h5>
            <h4>{{ totalCountList[0].아파트 }}</h4>
            <p style="color: gray">
              {{ totalCountList[0].법정동 + totalCountList[0].지번 }} (
              {{ totalCountList[0].도로명 }})
            </p>

            <b-card-text>
              <b-badge pill variant="primary">면적/층</b-badge>
              {{ totalCountList[0].층 }} 층,
              {{ totalCountList[0].전용면적 }}m<sup>2</sup>
              <br />

              <b-badge pill variant="info">건축일자</b-badge>
              {{ totalCountList[0].건축년도 }}

              <p>
                <b-badge pill variant="warning">최근거래금액</b-badge>
                {{ totalCountList[0].거래금액 }}
              </p>
            </b-card-text>
          </b-card>
        </div>
      </b-col>
      <b-col>
        <div>
          <b-card style="width: 100%">
            <h5 style="color: gray">
              <b-icon
                icon="exclamation-circle-fill"
                variant="secondary"
              ></b-icon>
              추천 시설 총
              <b-badge style="background-color: #f6a7c5">{{
                totalCountList[2].cnt
              }}</b-badge>
              개
            </h5>
            <h4>{{ totalCountList[2].아파트 }}</h4>
            <p style="color: gray">
              {{ totalCountList[2].법정동 + totalCountList[2].지번 }} (
              {{ totalCountList[2].도로명 }})
            </p>

            <b-card-text>
              <b-badge pill variant="primary">면적/층</b-badge>
              {{ totalCountList[2].층 }} 층,
              {{ totalCountList[2].전용면적 }}m<sup>2</sup>
              <br />

              <b-badge pill variant="info">건축일자</b-badge>
              {{ totalCountList[2].건축년도 }}

              <p>
                <b-badge pill variant="warning">최근거래금액</b-badge>
                {{ totalCountList[2].거래금액 }}
              </p>
            </b-card-text>
          </b-card>
        </div>
      </b-col>
    </b-row>
  </b-container>
  <b-container v-else class="bv-example-row mt-3">
    <b-row>
      <b-col><b-alert show>주택 목록이 없습니다.</b-alert></b-col>
    </b-row>
  </b-container>
</template>

<script>
import { mapState } from "vuex";

export default {
  name: "PersnalHouse",
  data() {
    return {
      apts: ["a"],
    };
  },
  computed: {
    ...mapState(["totalCountList", "persnalType"]),
  },
};
</script>

<style></style>

<template>
  <div v-if="persnalType == 1">
    <persnal-child />
  </div>
  <div v-else-if="persnalType == 2">
    <persnal-senior />
  </div>
  <div v-else-if="persnalType == 3">
    <persnal-disabled />
  </div>
  <div v-else-if="persnalType == 4">
    <persnal-animal />
  </div>
</template>

<script>
import { mapState } from "vuex";
import PersnalAnimal from "@/components/persnal/type/PersnalAnimal.vue";
import PersnalSenior from "@/components/persnal/type/PersnalSenior.vue";
import PersnalDisabled from "@/components/persnal/type/PersnalDisabled.vue";
import PersnalChild from "@/components/persnal/type/PersnalChild.vue";

export default {
  computed: {
    ...mapState(["totalCountList", "persnalType"]),
  },
  components: {
    PersnalAnimal,
    PersnalSenior,
    PersnalDisabled,
    PersnalChild,
  },
};
</script>

<style></style>

<template>
  <div class="context text-center">
    <b-container
      v-if="hospitalList && hospitalList.length != 0"
      class="bv-example-row mt-3"
    >
      <div v-for="(hos, index) in hospitalList" :key="index">
        <b-row>
          <b-col>
            <article class="card">
              <div class="card-body">
                <div v-if="rank[index].rank == 'A'">
                  <img
                    src="@/assets/rank_A.png"
                    width="145px"
                    style="margin: 0 auto"
                  />
                </div>
                <div v-else-if="rank[index].rank == 'B'">
                  <img
                    src="@/assets/rank_B.png"
                    width="150px"
                    style="margin: 0 auto"
                  />
                </div>
                <div v-else>
                  <img
                    src="@/assets/rank_C.png"
                    width="150px"
                    style="margin: 0 auto"
                  />
                </div>
              </div>
            </article>
          </b-col>
          <b-col>
            <article class="card" style="margin-bottom: 25px">
              <div class="card-header">
                <div>
                  <span style="margin-right: 10px"
                    ><img src="@/assets/covid.png" />
                  </span>
                  <h5>코로나19 안심병원</h5>
                </div>
              </div>
              <div class="card-body">
                <div v-for="(h, index) in hos" :key="index">
                  <span class="task__tag task__tag--illustration">
                    {{ h.name }}
                  </span>
                  <span class="task__tag task__tag--nomal">
                    {{ h.distance }} m
                  </span>
                </div>
              </div>
            </article>
          </b-col>
        </b-row>
      </div>
    </b-container>

    <b-container v-else class="bv-example-row mt-3">
      <b-row>
        <b-col><b-alert show>코로나 선별소가 없습니다.</b-alert></b-col>
      </b-row>
    </b-container>
  </div>
</template>

<script>
//import CovidListRow from "@/components/covid/CovidListRow.vue";
import { mapState } from "vuex";

export default {
  name: "CovidHosList",
  components: {
    //CovidListRow,
  },
  data() {
    return {
      rank: [],
    };
  },
  computed: {
    ...mapState(["hospitalList"]),
  },
  mounted() {
    //여기서 구현

    this.hospitalList.forEach((element) => {
      var min = 99999;
      element.forEach((ele) => {
        if (min > ele.distance) {
          min = ele.distance;
        }
      });
      let rank;

      if (min <= 1000) {
        rank = "A";
      } else if (min <= 2000) {
        rank = "B";
      } else if (min == 0) {
        rank = "C";
      } else {
        rank = "C";
      }

      this.rank.push({
        apt: element.apt,
        rank: rank,
      });
    });

    console.log(this.rank);
  },
};
</script>

<style></style>

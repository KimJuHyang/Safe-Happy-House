<template>
  <div>
    <covid-hos-list />
  </div>
</template>

<script>
import { mapState } from "vuex";
import CovidHosList from "@/components/covid/CovidHosList.vue";
export default {
  name: "CovidView",
  components: {
    CovidHosList,
  },
  data() {
    return {};
  },
  computed: {
    ...mapState(["hospitalList", "covidRank"]),
  },
};
</script>

<style></style>

<template>
  <div class="regist">
    <div v-if="this.modifyComment != null" class="regist_form">
      <textarea
        id="comment"
        name="comment"
        v-model="modifyComment.comment"
        cols="35"
        rows="2"
      ></textarea>
      <div style="float: right">
        <button
          class="g-actions-button23 g-actions-button23-default"
          @click="updateCommentCancel"
        >
          취소
        </button>
        <button
          class="g-actions-button33 g-actions-button33-default"
          @click="updateComment"
        >
          수정
        </button>
      </div>
    </div>
    <div v-else class="regist_form">
      <textarea
        id="comment"
        name="comment"
        v-model="comment"
        cols="35"
        rows="2"
      ></textarea>
      <button
        class="g-actions-button23 g-actions-button23-default"
        @click="registComment"
      >
        등록
      </button>
    </div>
  </div>
</template>

<script>
import http from "@/util/http-common";
import { mapState, mapMutations } from "vuex";
import { getMember } from "@/api/member";
const memberStore = "memberStore";
export default {
  name: "commentwrite",
  data() {
    return {
      // 차후 작성자 이름은 로그인 구현후 로그인한 사용자로 바꾼다.
      userid: "",
      comment: "",
    };
  },
  props: {
    articleno: { type: String },
    modifyComment: { type: Object },
  },
  computed: {
    ...mapState(memberStore, ["userInfo"]),
  },
  created() {
    getMember(
      this.$route.params.userid,
      ({ data }) => {
        this.userInfo = data;
      },
      (error) => {
        console.log(error);
      }
    );
  },
  methods: {
    ...mapMutations(memberStore, ["SET_USER_INFO"]),
    registComment() {
      console.log(this.articleno);
      console.log(this.comment);

      http
        .post("/comment", {
          articleno: this.articleno,
          comment: this.comment,
          userid: this.userInfo.userid,
        })
        .then(({ data }) => {
          let msg = "등록 처리시 문제가 발생했습니다.";
          if (data === "success") {
            msg = "등록이 완료되었습니다.";
          }
          alert(msg);

          // 작성글 지우기
          this.comment = "";

          this.$store.dispatch("getComments", `${this.articleno}`);
        });
    },
    updateComment() {
      http
        .put(`/comment`, {
          memono: this.modifyComment.memono,
          comment: this.modifyComment.comment,
        })
        .then(({ data }) => {
          let msg = "수정 처리시 문제가 발생했습니다.";
          if (data === "success") {
            msg = "수정이 완료되었습니다.";
          }
          alert(msg);

          // 도서평(댓글) 얻기.
          this.$store.dispatch(
            "getComments",
            `${this.modifyComment.articleno}`
          );
          this.$emit("modify-comment-cancel", false);

          //  this.$store.dispatch("getComments", `${this.articleno}`);
        });
    },
    updateCommentCancel() {
      this.$emit("modify-comment-cancel", false);
    },
  },
};
</script>

<style scoped>
.regist {
  padding: 10px;
}
.regist_form {
  text-align: left;
  border-radius: 5px;
  background-color: #d6e7fa;
  padding: 20px;
}

textarea {
  width: 90%;
  padding: 10px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  color: #787878;
  font-size: large;
}

.g-actions-button23 {
  padding: 8px 16px;
  align-items: baseline;
  border-radius: 3px;
  float: right;

  color: #3e4051;
  font-size: 13px;
  font-weight: 600;
  text-align: center;
}

.g-actions-button23 .right-4 {
  margin-right: 4px;
}

.g-actions-button23 .left-4 {
  margin-left: 4px;
}

.g-actions-button23-default {
  background: linear-gradient(to bottom, rgb(233, 240, 250), #b4dcfd);
  border: 1px solid #edeff5;
}

.g-actions-button23-default:hover {
  background: linear-gradient(to bottom, rgb(233, 240, 250), #9dc9fc);
  box-shadow: 0 0 1px rgba(214, 217, 225, 0.32);
}
</style>

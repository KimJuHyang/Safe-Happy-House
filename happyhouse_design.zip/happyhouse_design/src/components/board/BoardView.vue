<template>
  <div class="g-page">
    <b-row class="mb-1">
      <b-col class="text-left">
        <button
          class="g-actions-button g-actions-button-default"
          @click="listArticle"
        >
          목록<i class="fa fa-fw fa-pencil"></i>
        </button>
      </b-col>
      <b-col class="text-right">
        <button
          class="g-actions-button22 g-actions-button22-default"
          @click="moveModifyArticle"
        >
          글수정<i class="fa fa-fw fa-pencil"></i>
        </button>
        <button
          class="g-actions-button33 g-actions-button33-default"
          @click="deleteArticle"
        >
          글삭제<i class="fa fa-fw fa-pencil"></i>
        </button>
      </b-col>
    </b-row>

    <div class="g-table-body">
      <table cellspacing="0" class="g-table-list">
        <thead>
          <tr>
            <b-col class="text-left">
              <th>
                {{ article.articleno }}. {{ article.subject }} [{{
                  article.hit
                }}]
              </th>
            </b-col>
          </tr>
        </thead>

        <tbody>
          <tr>
            <b-col class="text-right">
              <td>
                작성자 : {{ article.userid }} 등록일 : {{ article.regtime }}
              </td>
            </b-col>
          </tr>
          <tr>
            <td>
              <div class="contenta" v-html="message"></div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <comment-write :articleno="`${article.articleno}`" />
    <comment-write
      v-if="isModifyShow && this.modifyComment != null"
      :modifyComment="this.modifyComment"
      @modify-comment-cancel="onModifyCommentCancel"
    />
    <comment
      v-for="(comment, index) in comments"
      :key="index"
      :comment="comment"
      @modify-comment="onModifyComment"
    />
  </div>
</template>

<script>
// import moment from "moment";
import http from "@/util/http-common";
import CommentWrite from "@/components/board/comment/CommentWrite.vue";
import Comment from "@/components/board/comment/Comment.vue";
import { mapActions, mapState } from "vuex";
//import { mapGetters } from 'vuex'
export default {
  data() {
    return {
      article: {},
      articleno: "",
      isModifyShow: false,
      modifyComment: Object,
    };
  },
  computed: {
    ...mapState(["comments"]),
    //...mapGetters(['comments']),
    message() {
      if (this.article.content)
        return this.article.content.split("\n").join("<br>");
      return "";
    },
    // changeDateFormat() {
    //   return moment(new Date(this.article.regtime)).format(
    //     "YYYY.MM.DD hh:mm:ss"
    //   );
    // },
  },
  created() {
    http.get(`/notice/${this.$route.params.articleno}`).then(({ data }) => {
      this.article = data;
    });

    this.getComment();
  },
  components: {
    CommentWrite,
    Comment,
  },
  methods: {
    ...mapActions(["getComments"]),
    listArticle() {
      this.$router.push({ name: "BoardList" });
    },
    moveModifyArticle() {
      this.$router.replace({
        name: "BoardUpdate",
        params: { articleno: this.article.articleno },
      });
      //   this.$router.push({ path: `/board/modify/${this.article.articleno}` });
    },
    deleteArticle() {
      if (confirm("정말로 삭제?")) {
        this.$router.replace({
          name: "BoardDelete",
          params: { articleno: this.article.articleno },
        });
      }
    },
    getComment() {
      console.log("댓글 가져올게!" + this.$route.params.articleno);
      this.getComments(this.$route.params.articleno);
    },
    onModifyComment(comment) {
      this.modifyComment = comment;
      this.isModifyShow = true;
    },
    onModifyCommentCancel(isShow) {
      this.isModifyShow = isShow;
    },
  },
};
</script>

<style>
.g-page {
  margin: 80px;
}

@media screen and (max-width: 600px) and (min-width: 300px) {
  .g-page {
    margin: 80px 0 24px 0;
  }
}

.g-table-list2 {
  background-color: #edeff5;
  width: 100%;
  text-align: center;
}

.g-actions-button22 {
  padding: 8px 16px;
  align-items: baseline;
  border-radius: 3px;

  color: #3e4051;
  font-size: 13px;
  font-weight: 600;
  text-align: center;
}

.g-actions-button22 .right-4 {
  margin-right: 4px;
}

.g-actions-button22 .left-4 {
  margin-left: 4px;
}

.g-actions-button22-default {
  background: linear-gradient(to bottom, rgb(233, 240, 250), #d0dcff);
  border: 1px solid #edeff5;
}

.g-actions-button22-default:hover {
  background: linear-gradient(to bottom, rgb(233, 240, 250), #b5b5fd);
  box-shadow: 0 0 1px rgba(214, 217, 225, 0.32);
}

.g-actions-button33 {
  padding: 8px 16px;
  align-items: baseline;
  border-radius: 3px;

  color: #3e4051;
  font-size: 13px;
  font-weight: 600;
  text-align: center;
}

.g-actions-button33 .right-4 {
  margin-right: 4px;
}

.g-actions-button33 .left-4 {
  margin-left: 4px;
}

.g-actions-button33-default {
  background: linear-gradient(to bottom, rgb(250, 233, 233), #ffd0d0);
  border: 1px solid #edeff5;
}

.g-actions-button33-default:hover {
  background: linear-gradient(to bottom, rgb(250, 233, 233), #fdb5be);
  box-shadow: 0 0 1px rgba(214, 217, 225, 0.32);
}
.contenta {
  height: 250px;
}
</style>

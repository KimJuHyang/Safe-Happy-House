<template>
  <main class="main">
    <div class="responsive-wrapper">
      <div class="main-header">
        <h1>게시판</h1>
      </div>

      <div class="content-header">
        <div class="content-header-intro">
          <h2>자유롭게 질문과 답변을 남겨보세요.</h2>
          <p>게시글 열람 및 작성, 댓글 작성은 회원에게만 권한이 있습니다.</p>
        </div>

        <div>
          <button
            class="g-actions-button g-actions-button-default"
            @click="moveWrite()"
          >
            글작성<i class="fa fa-fw fa-pencil"></i>
          </button>
        </div>
      </div>

      <div class="g-table-body">
        <div v-if="articles.length">
          <table cellspacing="0" class="g-table-list">
            <thead>
              <tr>
                <th>글번호</th>
                <th>제목</th>
                <th>조회수</th>
                <th>작성자</th>
                <th>작성일</th>
              </tr>
            </thead>

            <tbody>
              <board-list-row
                v-for="(article, index) in articles"
                :key="index"
                v-bind="article"
              />
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </main>
</template>

<script>
import http from "@/util/http-common";
import BoardListRow from "@/components/board/child/BoardListRow";

export default {
  name: "BoardList",
  components: {
    BoardListRow,
  },
  data() {
    return {
      articles: [],
    };
  },
  created() {
    // let param = {
    //   pg: 1,
    //   spp: 20,
    //   key: null,
    //   word: null,
    // };

    http
      .get(`/notice`)
      .then(({ data }) => {
        this.articles = data;
      })
      .catch(({ data }) => {
        console.log(data);
      });
  },
  methods: {
    moveWrite() {
      this.$router.push({ name: "BoardWrite" });
    },
  },
};
</script>

<style scope>
body {
  background-color: #f9fafc;
  font-family: Helvetica Neue;
}

a {
  color: #4273d5;
  text-decoration: none;
}

a:hover {
  color: #4066b5;
}

.g-body-copy {
  font-size: 14px;
  font-weight: 400;
  color: #3e4051;
}

.g-page {
  margin: 80px;
}

@media screen and (max-width: 600px) and (min-width: 300px) {
  .g-page {
    margin: 80px 0 24px 0;
  }
}

.g-actions-button {
  padding: 8px 16px;
  align-items: baseline;
  border-radius: 3px;

  color: #3e4051;
  font-size: 13px;
  font-weight: 600;
  text-align: center;
}

.g-actions-button i {
  margin: 0;
  width: 100%;
}

.g-actions-button .right-4 {
  margin-right: 4px;
}

.g-actions-button .left-4 {
  margin-left: 4px;
}

.g-actions-button-default {
  background: linear-gradient(to bottom, #fff, #f5f6f9);
  border: 1px solid #edeff5;
}

.g-actions-button-default:hover {
  background: linear-gradient(to bottom, #fff, #efeff6);
  box-shadow: 0 0 1px rgba(214, 217, 225, 0.32);
}

.g-actions-button-pager {
  background-color: #fff;
  border: 1px solid #edeff5;
}

.g-forms-input {
  display: flex;
  align-items: center;
}

.g-forms-input-search-bar-icon {
  position: relative;
  right: 32px;
  color: #3e4051;
  font-size: 13px;
}

.g-table-body {
  background-color: #fff;
  border-radius: 3px;
  border: 1px solid #edeff5;
}

.g-table-actions {
  padding: 16px;
  margin: 0;
  list-style: none;

  display: -webkit-box;
  display: -moz-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;

  justify-content: space-between;
  align-items: center;
}

.g-table-actions-col {
  display: flex;
  justify-content: flex-start;
}

.g-header {
  font-family: Montserrat;
  color: #3e4051;
  text-align: left;
  display: flex;
  flex-flow: row wrap;
  align-items: baseline;
  margin: 24px 0;
}

.g-header .page-title {
  font-size: 24px;
}

.g-header .sub-title {
  font-size: 16px;
}

.g-header-value {
  margin-right: 16px;
}

.g-table-list {
  table-layout: fixed;
  width: 100%;
  white-space: nowrap;
}

.g-table-list thead tr {
  background-color: #edeff5;
  width: 100%;
  text-align: center;
}

.g-table-list tr {
  vertical-align: baseline;
}

.g-table-list td {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  border-bottom: 1px solid #edeff5;
}

.g-table-list th,
td {
  font-size: 14px;
  color: #3e4051;
  padding: 16px 8px;
}

.g-table-list td:first-child {
  padding-left: 24px;
  width: 32px;
}

.g-table-list td:last-child {
  padding-right: 24px;
  text-align: center;
}

.g-table-list th:last-child {
  padding-right: 24px;
  text-align: center;
}

.g-table-list-date {
  text-align: center;
  padding-right: 24px;
}

.g-table-list-col-title {
  font-size: 13px;
  font-weight: 500;
  color: #474e5d;
}

.g-table-list-col-small-copy {
  font-size: 11px;
  color: #3e4051;
}

.g-table-list-col-edit {
  width: 6%;
}

.g-table-list-col-sku {
  width: 14%;
}

.g-table-list-col-listing {
  width: 40%;
}

.g-table-list-col-desc {
  width: 16%;
}

.g-table-list-col-money {
  width: 8%;
}

.g-table-list-col-date {
  width: 16%;
}

@media screen and (max-width: 1080px) and (min-width: 980px) {
  .g-table-list-rwd {
    display: none;
  }
}

@media screen and (max-width: 980px) and (min-width: 600px) {
  .g-table-list-rwd {
    display: none;
  }
}

@media screen and (max-width: 600px) and (min-width: 300px) {
  .g-table-list-rwd {
    display: none;
  }
}

.g-table-list-rwd {
  padding-right: 16px;
}
</style>

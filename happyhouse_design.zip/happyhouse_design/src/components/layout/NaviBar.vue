<template>
  <div>
    <header class="header">
      <div class="header-content responsive-wrapper">
        <div class="header-logo">
          <router-link :to="{ name: 'House' }" class="link">
            <a href="#">
              <div>
                <img src="@/assets/maker.png" />
              </div>
            </a>
          </router-link>
        </div>

        <div class="header-navigation">
          <nav class="header-navigation-links">
            <div class="container_nav">
              <div class="tabs">
                <router-link :to="{ name: 'Notice' }" class="link">
                  <input type="radio" id="radio-1" name="tabs" />
                  <label class="tab" for="radio-1">게시판</label>
                </router-link>

                <router-link :to="{ name: 'House' }" class="link">
                  <input type="radio" id="radio-2" name="tabs" />
                  <label class="tab" for="radio-2">전국 아파트 정보</label>
                </router-link>

                <router-link :to="{ name: 'Covid' }" class="link">
                  <input type="radio" id="radio-3" name="tabs" />
                  <label class="tab" for="radio-3">관심단지 코로나 등급</label>
                </router-link>

                <div v-if="userInfo">
                  <router-link :to="{ name: 'Persnal' }" class="link">
                    <input type="radio" id="radio-3" name="tabs" />
                    <label class="tab" for="radio-3"
                      >맞춤 주택 추천서비스</label
                    >
                  </router-link>
                </div>
              </div>
            </div>
          </nav>
          <div class="header-navigation-actions">
            <!-- <a href="#" class="avatar">
              <b-icon icon="person-fill"></b-icon>
            </a> -->
            <b-navbar-nav class="ml-auto" v-if="userInfo">
              <b-nav-item-dropdown right>
                <template #button-content>
                  <b-avatar
                    variant="primary"
                    v-text="
                      userInfo ? userInfo.userid.charAt(0).toUpperCase() : ''
                    "
                  ></b-avatar
                  >{{ userInfo.username }} ({{ userInfo.userid }})
                </template>
                <b-dropdown-item href="#"
                  ><router-link :to="{ name: 'MyPage' }" class="link"
                    ><b-icon icon="person-circle"></b-icon>
                    내정보보기</router-link
                  ></b-dropdown-item
                >
                <b-dropdown-item href="#">
                  <div @click.prevent="onClickLogout">
                    <b-icon icon="key"></b-icon> 로그아웃
                  </div>
                </b-dropdown-item>
              </b-nav-item-dropdown>
            </b-navbar-nav>

            <b-navbar-nav class="ml-auto" v-else>
              <b-nav-item-dropdown right>
                <template #button-content>
                  <b-icon icon="people" font-scale="2"></b-icon>
                </template>
                <b-dropdown-item href="#"
                  ><router-link :to="{ name: 'SignUp' }" class="link"
                    ><b-icon icon="person-circle"></b-icon>
                    회원가입</router-link
                  ></b-dropdown-item
                >
                <b-dropdown-item href="#"
                  ><router-link :to="{ name: 'SignIn' }" class="link"
                    ><b-icon icon="key"></b-icon> 로그인</router-link
                  ></b-dropdown-item
                >
              </b-nav-item-dropdown>
            </b-navbar-nav>
          </div>
        </div>
        <a href="#" class="button">
          <i class="ph-list-bold"></i>
          <span>Menu</span>
        </a>
      </div>
    </header>
  </div>
</template>

<script>
import { mapState, mapMutations } from "vuex";
const memberStore = "memberStore";

export default {
  name: "NaviBar",
  computed: {
    ...mapState(memberStore, ["isLogin", "userInfo"]),
  },
  watch: {
    isLogin: function () {
      console.log("change!!!!!");
    },
  },
  methods: {
    ...mapMutations(memberStore, ["SET_IS_LOGIN", "SET_USER_INFO"]),
    onClickLogout() {
      this.SET_IS_LOGIN(false);
      this.SET_USER_INFO(null);
      sessionStorage.removeItem("access-token");
      if (this.$route.path != "/") this.$router.push({ name: "House" });
    },
  },
};
</script>

<style lang="scss">
@import "@/assets/scss/home.scss";
@import "@/assets/scss/navi.scss";
</style>

<template>
  <div>
    <main class="main">
      <div class="responsive-wrapper">
        <div class="main-header">
          <h1>관심단지 코로나19 안심 등급</h1>
        </div>

        <div class="content-header">
          <div class="content-header-intro">
            <h2>내 관심단지는 몇등급 일까요?</h2>
            <p>
              관심단지 해당 구군에 있는 코로나19 안심병원의 정보와 거리를
              안내합니다. <br />
              이를 기반으로 1km 이하에 있다면 A등급, 2km 이하에 있다면 B등급, 그
              외는 C등급을 부여합니다.
            </p>
          </div>
        </div>
        <div>
          <b-row>
            <b-col cols="6" align="left">
              <house-like />
            </b-col>
            <b-col cols="6">
              <covid-view />
            </b-col>
          </b-row>
        </div>
      </div>
    </main>
  </div>
</template>

<script>
import HouseLike from "@/components/house/HouseLike.vue";
import CovidView from "@/components/covid/CovidView.vue";
export default {
  name: "Covid",
  components: {
    HouseLike,
    CovidView,
  },
};
</script>

<style></style>

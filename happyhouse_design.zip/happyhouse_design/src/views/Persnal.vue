<template>
  <main class="main">
    <div class="responsive-wrapper">
      <div class="main-header">
        <h1>맞춤 주택 서비스</h1>
      </div>

      <div class="content-header">
        <div class="content-header-intro">
          <h2>거주 형태에 따라서 안전한 맞춤 주택을 추천해드려요.</h2>
          <p>
            시/군구를 선택하고 거주유형을 선택하여, 해당 지역에서 가장 안전한
            집을 조회하세요!
          </p>
        </div>
        <b-row>
          <b-col>
            <div style="align: center">
              <span
                class="task__tag task__tag--design"
                style="margin-right: 150px"
                >시/도</span
              >
              <span
                class="task__tag task__tag--design"
                style="margin-right: 150px"
                >구/군</span
              >

              <span class="task__tag task__tag--copyright">거주 유형</span>
            </div>

            <persnal-select-bar></persnal-select-bar>
          </b-col>
        </b-row>
      </div>
      <div>
        <div class="content-main">
          <b-row>
            <b-col cols="12">
              <persnal-house />
            </b-col>
          </b-row>
          <b-row>
            <b-col cols="12">
              <persnal-detail />
            </b-col>
          </b-row>
          <b-row>
            <b-col cols="12">
              <persnal-map />
            </b-col>
          </b-row>
        </div>
      </div>
    </div>
  </main>
</template>
<script>
// import HouseList from "@/components/house/HouseList.vue";
import PersnalMap from "@/components/persnal/PersnalMap.vue";
import PersnalSelectBar from "@/components/persnal/PersnalSelectBar.vue";
import PersnalHouse from "@/components/persnal/PersnalHouse.vue";
import PersnalDetail from "@/components/persnal/PersnalDetail.vue";
export default {
  name: "House",
  components: {
    //HouseList,
    PersnalMap,
    PersnalSelectBar,
    PersnalHouse,
    PersnalDetail,
  },
};
</script>
<style scoped>
.underline-orange {
  display: inline-block;
  background: linear-gradient(
    180deg,
    rgba(255, 255, 255, 0) 70%,
    rgba(231, 149, 27, 0.3) 30%
  );
}
</style>

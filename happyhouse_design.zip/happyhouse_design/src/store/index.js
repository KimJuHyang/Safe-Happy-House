import Vue from "vue";
import Vuex from "vuex";
import http from "@/util/http-common.js";
import axios from "axios";
import createPersistedState from "vuex-persistedstate";

Vue.use(Vuex);

import memberStore from "@/store/modules/memberStore.js";

export default new Vuex.Store({
  state: {
    sidos: [{ value: null, text: "이부분을 선택하세요" }],
    guguns: [{ value: null, text: "이부분을 선택하세요" }],
    houses: [],
    house: null,
    addrList: [],
    isOk: false,
    likeList: [],
    hospitalList: [],
    comments: [],
    reviews: [],
    aptCode: null,
    tempcovidList: [],
    persnal: null,
    totalCountList: [],
    persnalType: null,
    persnalPlace: ["어린이집"],
    selectComment: null,
    policeList: [],
    fireList: [],
    transPoliceList: [],
    transFireList: [],
    avg: 0,
    sum: 0,
    aptName: null,
    reviewList: [],
    sameList: [],
    crimeList: [],
    mysido: null,
    mygugun: null,
    myType: null,
    aptdong: null,
    aptjibun: null,
  },
  mutations: {
    SET_SIDO_LIST(state, sidos) {
      sidos.forEach((sido) => {
        state.sidos.push({ value: sido.sidoCode, text: sido.sidoName });
      });
    },
    SET_GUGUN_LIST(state, guguns) {
      guguns.forEach((gugun) => {
        state.guguns.push({ value: gugun.gugunCode, text: gugun.gugunName });
      });
    },
    async SET_HOUSE_LIST(state, houses) {
      state.houses = houses;

      state.addrList = [];

      //****** 위치정보 가져오기 *******
      const script = document.createElement("script");
      script.onload = () => kakao.maps.load(this.initMap);
      script.src =
        "http://dapi.kakao.com/v2/maps/sdk.js?autoload=false&appkey=bc7c2e75075b41370b5dd6270a0779e0&libraries=services";
      document.head.appendChild(script);

      var ps = new kakao.maps.services.Places();

      //주소 리스트만 만들기
      houses.forEach((house) => {
        ps.keywordSearch(house.아파트, placesSearchCB);

        // 키워드 검색 완료 시 호출되는 콜백함수 입니다
        function placesSearchCB(data, status) {
          if (status === kakao.maps.services.Status.OK) {
            state.addrList.push({
              아파트: house.아파트,
              지번: house.지번,
              법정동: house.법정동,
              도로명: house.도로명,
              층: house.층,
              전용면적: house.전용면적,
              건축년도: house.건축년도,
              거래금액: house.거래금액,
              시군구코드: house.법정동시군구코드,
              addr: house.법정동 + house.지번,
              lat: data[0].y,
              lon: data[0].x,
            });
          }
        }
      });
      state.isOk = !state.isOk;
      console.log(state.addrList);
    },
    SET_DATAIL_HOUSE(state, house) {
      state.house = house;
      console.log("아파트 검색" + state.house);
    },
    SET_ADD_LIKE(state, house) {
      //****** 위치정보 가져오기 *******
      const script = document.createElement("script");
      script.onload = () => kakao.maps.load(this.initMap);
      script.src =
        "http://dapi.kakao.com/v2/maps/sdk.js?autoload=false&appkey=bc7c2e75075b41370b5dd6270a0779e0&libraries=services";
      document.head.appendChild(script);

      let ps = new kakao.maps.services.Places();

      var str = "";
      str += house.법정동시군구코드;
      var res = str.substr(0, 2);

      console.log("추출" + res);
      ps.keywordSearch(house.아파트, placesSearchCB);

      // 키워드 검색 완료 시 호출되는 콜백함수 입니다
      async function placesSearchCB(data, status) {
        if (status === (await kakao.maps.services.Status.OK)) {
          state.likeList.push({
            아파트: house.아파트,
            지번: house.지번,
            법정동: house.법정동,
            도로명: house.도로명,
            층: house.층,
            전용면적: house.전용면적,
            건축년도: house.건축년도,
            거래금액: house.거래금액,
            시군구코드: house.법정동시군구코드,
            시도: res,
            lat: data[0].y,
            lon: data[0].x,
          });
        }
      }

      //여기서 바로 코로나 리스트 검사해서 넣어주는게 좋겠다.
      console.log(state.likeList);
    },
    CLEAR_GUGUN_LIST(state) {
      state.guguns = [{ value: null, text: "이부분을 선택하세요" }];
      state.addrList = [];
    },
    CLEAR_SIDO_LIST(state) {
      state.sidos = [{ value: null, text: "이부분을 선택하세요" }];
      state.house = null;
      state.houses = [];
    },
    CLEAR_MYTYPE(state) {
      state.myType = null;
    },

    SET_COMMENTS(state, data) {
      console.log("댓글얻어오기");
      console.log(state);
      console.log(data);
      state.comments = data;
    },
    SET_REVIEWS(state, data) {
      console.log("리뷰 얻어오기");
      console.log(state);
      console.log(data);
      state.reviews = data;

      if (state.reviews.length != 0) {
        let sum = 0;
        for (let i = 0; i < state.reviews.length; i++) {
          sum = sum + state.reviews[i].grade;
        }
        let avg = sum / state.reviews.length;
        state.avg = Math.round(avg);
        console.log("평균");
        console.log(avg);
      } else {
        state.avg = 0;
      }
    },
    SET_APTNAME(state, data) {
      console.log("아파트이름 얻어오기");
      console.log(state);
      console.log(data);
      state.aptName = data.aptName;
      state.aptdong = data.dong;
      state.aptjibun = data.jibun;
      //state.aptCode = data[0].aptCode;
      //state.aptName = data
      //console.log(state.aptCode);
    },

    SET_COVID_LIST(state, datas) {
      //let mygugun = "";
      state.tempcovidList = datas;
      // state.guguns.forEach((gugun) => {
      //   if (likehouse.시군구코드 === gugun.value) {
      //     console.log("같다." + gugun.text);
      //   }
      // });
    },
    SET_LIKE_COVID_LIST(state, like) {
      console.log("코로나 리스트");
      console.log(like.data);
      console.log("좋아하는 목록");
      console.log(like.like);

      let mygugun;
      let mysido;
      var str = "";
      str += like.like.법정동시군구코드;
      var res = str.substr(0, 2);
      res = res.substr(0, 2);
      //console.log(like.시);
      console.log("테스트");
      console.log(like);
      state.guguns.forEach((gugun) => {
        if (like.like.법정동시군구코드 == gugun.value) {
          mygugun = gugun.text;
        }
      });

      state.sidos.forEach((sido) => {
        if (res == sido.value) {
          let temp = "";
          temp += sido.text;
          let str = temp.substr(0, 2);
          mysido = str;
        }
      });
      console.log(mygugun + " " + mysido + "검색요망");

      var newHosList = [];

      // 여기서 위도 경도 받아오기
      //2. 아래 hos 리스트 위도경도 설정하기
      //3. 각각 api 호출해서 랭크 넣어주기 (1km 이하 A 2km 이하 B 그외 C)
      //4. 최종 랭크까지 넣은애들 hos 리스트에 넣어주기
      like.data.forEach((temp) => {
        if (temp.sgguNm == mygugun && temp.sidoNm == mysido) {
          newHosList.push({
            name: temp.yadmNm,
            apt: like.like.아파트,
            tel: temp.telno,
            addr: temp.sidoNm + " " + temp.sgguNm,
            code: like.like.법정동시군구코드,
            sido: temp.sidoNm,
            distance: 0,
          });
        }
      });

      //****** 위치정보 가져오기 *******
      const script = document.createElement("script");
      script.onload = () => kakao.maps.load(this.initMap);
      script.src =
        "http://dapi.kakao.com/v2/maps/sdk.js?autoload=false&appkey=bc7c2e75075b41370b5dd6270a0779e0&libraries=services";
      document.head.appendChild(script);
      let ps = new kakao.maps.services.Places();

      state.likeList.forEach((like) => {
        newHosList.forEach((hospital) => {
          if (like.아파트 == hospital.apt) {
            ps.keywordSearch(hospital.name, placesSearchCB);
          }
          // 키워드 검색 완료 시 호출되는 콜백함수 입니다

          async function placesSearchCB(data, status) {
            if (status === kakao.maps.services.Status.OK) {
              console.log(like.lat + " " + like.lon);
              console.log(String(data[0].y) + " " + String(data[0].x));

              const params = {
                lat1: like.lat,
                lon1: like.lon,
                lat2: String(data[0].y),
                lon2: String(data[0].x),
              };

              await http
                .get(`/map/distance`, { params })
                .then((response) => {
                  console.log(response);
                  console.log("미터!!!" + JSON.stringify(response.data[0]));
                  hospital.distance = response.data[0];
                })
                .catch();
            }
          }
        });
      });

      // if (parseInt(dis[0]) <= 1000) {
      //   console.log("A");
      // } else if (parseInt(dis[0]) <= 2000) {
      //   console.log("B");
      // } else {
      //   console.log("C");
      // }
      //let covidRank = [];

      newHosList.forEach((element) => {
        //let rest = 9999;
        for (const [key, value] of Object.entries(element)) {
          console.log(`${key}: ${value}`);
        }
        console.log(element);
        console.log(element.distance);
        // element.forEach((ele) => {
        //   if (rest > ele.rank) {
        //     rest = ele.rank;
        //   }
        // });

        // let rank;
        // if (rest <= 1000) {
        //   rank = "A";
        // } else if (rest <= 2000) {
        //   rank = "B";
        // } else {
        //   rank = "C";
        // }
        // covidRank.push({
        //   apt: element.아파트,
        //   rank: rank,
        // });
      });

      // // console.log(covidRank);

      state.hospitalList.push(newHosList);
      console.log(state.hospitalList);

      // 랭크 세팅도 여기서
    },
    REMOVE_LIKE_LIST(state, house) {
      for (let i = 0; i < state.likeList.length; i++) {
        if (state.likeList[i].아파트 === house.아파트) {
          state.likeList.splice(i, 1);
          i--;
        }
      }

      // for (let i = 0; i < state.hospitalList.length; i++) {
      //   console.log(state.hospitalList[i].[0]);
      // }
      let remove = [];
      state.hospitalList.forEach((element) => {
        if (element[0].apt != house.아파트) {
          remove.push(element);
        }
      });

      state.hospitalList = remove;

      //한번더 지워주기
      if (state.likeList.length == 0) {
        state.hospitalList = [];
      }
    },
    SET_COVID_RANK(state, aptname) {
      console.log(state);
      console.log("코로나 랭크", aptname);
    },
    SET_PERSNAL_TYPE(state, persnal) {
      // 여기서 해당하는  주소 배열을 얻어야함
      state.persnalType = persnal.type;
      state.persnal = persnal.location;
      //****** 위치정보 가져오기 *******
      const script = document.createElement("script");
      script.onload = () => kakao.maps.load(this.initMap);
      script.src =
        "http://dapi.kakao.com/v2/maps/sdk.js?autoload=false&appkey=bc7c2e75075b41370b5dd6270a0779e0&libraries=services";
      document.head.appendChild(script);

      // 장소 검색 객체를 생성합니다
      var ps = new kakao.maps.services.Places();

      let resultList = [];

      state.addrList.forEach((house) => {
        resultList.push({
          아파트: house.아파트,
          지번: house.지번,
          법정동: house.법정동,
          도로명: house.도로명,
          층: house.층,
          전용면적: house.전용면적,
          건축년도: house.건축년도,
          거래금액: house.거래금액,
          시군구코드: house.법정동시군구코드,
          lat: house.lat,
          lon: house.lon,
          cnt: 0,
        });
      });

      if (persnal.type == 1) {
        state.persnalPlace = ["어린이집", "놀이터", "키즈카페", "소아과"];
      } else if (persnal.type == 2) {
        state.persnalPlace = ["경찰서", "소방서", "노인 복지센터"];
      } else if (persnal.type == 3) {
        state.persnalPlace = ["장애인 복지센터", "특수학교"];
      } else {
        state.persnalPlace = ["애견카페", "동물병원", "공원"];
      }

      for (let index = 0; index < state.persnalPlace.length; index++) {
        searchPlaces(persnal.location + " 근처 " + state.persnalPlace[index]);
      }

      // 키워드 검색을 요청하는 함수입니다
      async function searchPlaces(persnal) {
        console.log(persnal);
        var keyword = persnal;

        // 장소검색 객체를 통해 키워드로 장소검색을 요청합니다
        await ps.keywordSearch(keyword, placesSearchCB);
      }

      // 장소검색이 완료됐을 때 호출되는 콜백함수 입니다
      async function placesSearchCB(data, status) {
        if (status === kakao.maps.services.Status.OK) {
          await displayPlaces(data);

          // if (state.persnalType == 2) {
          //   //console.log("노인");
          //   getPoliceAndFire(data);
          // }
        }
      }
      async function displayPlaces(places) {
        for (let i = 0; i < state.addrList.length; i++) {
          for (let j = 0; j < places.length; j++) {
            const params = {
              lat1: state.addrList[i].lat,
              lon1: state.addrList[i].lon,
              lat2: String(places[j].y),
              lon2: String(places[j].x),
            };

            await http.get(`/map/distance`, { params }).then((response) => {
              if (response.data[0] <= 2000) {
                resultList[i].cnt++;
              }
            });
          }
        }

        let arr = resultList.sort((a, b) => b.cnt - a.cnt);
        //여기서 아파트이름 중복되는 애 하나만 제거
        state.totalCountList = arr.slice(0, 3);

        //여기서 그냥 바로 호출
        if (persnal.type == 2) {
          setPoliceFire();
        }

        async function setPoliceFire() {
          for (let index = 0; index < state.persnalPlace.length - 1; index++) {
            await searchPlaces(
              persnal.location + " 근처 " + state.persnalPlace[index]
            );
          }

          // 키워드 검색을 요청하는 함수입니다
          async function searchPlaces(persnal) {
            var keyword = persnal;

            // 장소검색 객체를 통해 키워드로 장소검색을 요청합니다
            await ps.keywordSearch(keyword, placesSearchCB);
          }

          // 장소검색이 완료됐을 때 호출되는 콜백함수 입니다
          async function placesSearchCB(data, status) {
            if (status === kakao.maps.services.Status.OK) {
              await getPoliceAndFire(data);
            }
          }

          let policeList = [];
          let fireList = [];
          async function getPoliceAndFire(places) {
            //persnal.location
            // console.log(state.totalCountList);
            // console.log(places);
            for (let i = 0; i < state.totalCountList.length; i++) {
              let time = 9999;
              let target = null;
              let lat1 = null;
              let lon1 = null;
              let lat2 = null;
              let lon2 = null;

              for (let j = 0; j < places.length; j++) {
                const params = {
                  lat1: state.totalCountList[i].lat,
                  lon1: state.totalCountList[i].lon,
                  lat2: String(places[j].y),
                  lon2: String(places[j].x),
                  area: state.persnal,
                };

                await http.get(`/map/time`, { params }).then((response) => {
                  if (time > response.data) {
                    time = response.data;
                    target = places[j].place_name;
                    lat1 = state.totalCountList[i].lat;
                    lon1 = state.totalCountList[i].lon;
                    lat2 = places[j].y;
                    lon2 = places[j].x;
                  }
                });
              }

              if (time >= 1000) {
                time = time / 1000;
              } else if (time >= 100) {
                time = time / 100;
              }
              if (
                target.includes("경찰서") ||
                target.includes("파출소") ||
                target.includes("지구대") ||
                target.includes("치안센터")
              ) {
                policeList.push({
                  apt: state.totalCountList[i].아파트,
                  time: time,
                  target: target,
                  lat1: lat1,
                  lon1: lon1,
                  lat2: lat2,
                  lon2: lon2,
                });
              } else {
                fireList.push({
                  apt: state.totalCountList[i].아파트,
                  time: time,
                  target: target,
                  lat1: lat1,
                  lon1: lon1,
                  lat2: lat2,
                  lon2: lon2,
                });
              }
            }
            //console.log(timeList);
          }
          state.policeList = policeList;
          state.fireList = fireList;
          // tempPolice.forEach((police) => {
          //   //비교해서 더 작은애를 넣어주어야함.
          //   let maxX;
          //   let maxY;
          //   let minX;
          //   let minY;
          //   if (parseInt(police.lon1) >= parseInt(police.lon2)) {
          //     maxX = police.lon1;
          //     minX = police.lon2;
          //   }
          //   if (parseInt(police.lat1) >= parseInt(police.lat2)) {
          //     maxY = police.lat1;
          //     minY = police.lat2;
          //   }
          //   console.log(maxX + " " + minX + " " + maxY + " " + minY);
          //   const params = {
          //     apiKey: "a6ef10eb76e64e699e3ab12dc5ce6012",
          //     type: "all",
          //     minX: minX,
          //     maxX: maxX,
          //     minY: minY,
          //     maxY: maxY,
          //     getType: "json",
          //   };
          //   http
          //     .get(`https://openapi.its.go.kr:9443/trafficInfo`, { params })
          //     .then((response) => {
          //       console.log(response);
          //     })
          //     .catch();
          // });
        }
      }
    },
    SET_TRANCE_LIST_POLICE(state, data) {
      state.transPoliceList.push({
        roadName: data.roadName,
        speed: data.speed,
      });
    },
    SET_TRANCE_LIST_FIRE(state, data) {
      console.log("소방서 받은것");
      state.transFireList.push({
        roadName: data.roadName,
        speed: data.speed,
      });
    },
    CLEAR_TRANS_LIST(state) {
      state.transPoliceList = [];
      state.transFireList = [];
    },
    SET_APTETC(state, data) {
      // state.revieList;
      console.log("지금 스테이트 읽히는지");
      console.log(state.reviewList);

      let avg = 0;
      state.reviewList.forEach((element) => {
        if (element.aptName === data.아파트) {
          avg = Math.round(element.grade / element.cnt);
        }
      });

      console.log("구한 평균: " + avg);
      let tempList = [];

      state.reviewList.forEach((element) => {
        if (element.aptName != data.아파트) {
          let temp = Math.round(element.grade / element.cnt);
          if (temp == avg) {
            tempList.push(element);
          }
        }
      });
      console.log("비슷한애들");
      state.sameList = tempList;
      //console.log(tempList);
    },

    SET_REVIEWLIST(state, data) {
      //애초부터 넣을때부터 평균을 계산하고 넣어주기
      console.log(data);
      let flag = false;

      if (state.reviewList.length > 0) {
        state.reviewList.forEach((element) => {
          if (element.aptName == data.aptName) {
            // 이미 있음
            element.grade += data.grade;
            element.cnt++;
            flag = true;
          }
        });

        if (!flag) {
          const param = {
            grade: data.grade,
            aptName: data.aptName,
            aptdong: data.aptdong,
            aptjibun: data.aptjibun,
            cnt: 1,
          };
          state.reviewList.push(param);
        }
      } else {
        const param = {
          grade: data.grade,
          aptName: data.aptName,
          aptdong: data.aptdong,
          aptjibun: data.aptjibun,
          cnt: 1,
        };
        state.reviewList.push(param);
      }

      console.log(state.reviewList);
    },

    SET_MYSIDO_NAME(state, param) {
      state.mysido = param;
    },
    SET_MYGUGUN_NAME(state, param) {
      state.mygugun = param;
    },
    CLEAR_TYPE(state) {
      state.myType = null;
    },
    SET_MYTYPE(state, param) {
      state.myType = param;
    },
  },
  actions: {
    //비동기 통신은 여기다가
    getSido({ commit }) {
      http
        .get(`/map/sido`)
        .then((response) => {
          commit("SET_SIDO_LIST", response.data);
        })
        .catch();
    },
    getGugun({ commit }, sidoCode) {
      const params = { sido: sidoCode };
      http
        .get(`/map/gugun`, { params })
        .then((response) => {
          commit("SET_GUGUN_LIST", response.data);
        })
        .catch();
    },
    getHouseList({ commit }, gugunCode) {
      //요걸 백엔드에서 api를 받아와야한대.
      const SERVICE_KEY = process.env.VUE_APP_APT_DEAL_API_KEY;
      const SERVICE_URL =
        "http://openapi.molit.go.kr/OpenAPI_ToolInstallPackage/service/rest/RTMSOBJSvc/getRTMSDataSvcAptTradeDev";
      const params = {
        LAWD_CD: gugunCode,
        DEAL_YMD: "202110",
        serviceKey: decodeURIComponent(SERVICE_KEY), //여기서 페이징 처리, 년도도 만들어놓으면 댐
      };
      http
        .get(SERVICE_URL, { params })
        .then((response) => {
          commit("SET_HOUSE_LIST", response.data.response.body.items.item);
          // commit("SET_PERSNAL_TYPE", params);
        })
        .catch();
    },
    detailHouse({ commit }, house) {
      //나중에 하우스에 있는 일련번호를 이용해서 API호출
      console.log(house);
      commit("SET_DATAIL_HOUSE", house);
    },
    addLike({ commit }, house) {
      commit("SET_ADD_LIKE", house);
    },
    getCovidHosp({ commit }, house) {
      commit("GET_COVID_HOSP", house);
    },
    getComments({ commit }, no) {
      console.log("받은것" + no);

      http
        .get(`/comment/${no}`)
        .then((response) => {
          commit("SET_COMMENTS", response.data);
        })
        .catch();
    },
    getCovidList({ commit }, like) {
      console.log("이거 받음", like);
      //http://apis.data.go.kr/B551182/pubReliefHospService/getpubReliefHospList
      //요걸 백엔드에서 api를 받아와야한대.
      const SERVICE_KEY = process.env.VUE_APP_APT_DEAL_API_KEY;
      const SERVICE_URL =
        "http://apis.data.go.kr/B551182/pubReliefHospService/getpubReliefHospList";
      const params = {
        pageNo: encodeURIComponent("1"),
        numOfRows: encodeURIComponent("500"),
        spclAdmTyCd: encodeURIComponent("99"),
        serviceKey: decodeURIComponent(SERVICE_KEY), //여기서 페이징 처리, 년도도 만들어놓으면 댐
      };
      http
        .get(SERVICE_URL, { params })
        .then((response) => {
          console.log(response.data.response.body.items.item);
          const test = {
            data: response.data.response.body.items.item,
            like: like,
          };
          //commit("SET_COVID_LIST", response.data.response.body.items);
          commit("SET_LIKE_COVID_LIST", test);
        })
        .catch();
    },
    removeLike({ commit }, house) {
      commit("REMOVE_LIKE_LIST", house);
    },
    setCovidRank({ commit }, aptname) {
      commit("SET_COVID_RANK", aptname);
    },
    getPersnalMap({ commit }, params) {
      commit("SET_PERSNAL_TYPE", params);
      commit("CLEAR_TRANS_LIST");
      // commit("SET_TRANCE_DATA");
    },
    getReviews({ commit }, house) {
      console.log("받은것" + house);
      console.log("코드 ");
      console.log(house);
      const params = {
        aptName: house.아파트,
        dong: house.법정동,
        jibun: house.지번,
      };
      http
        .get(`/review/${house.아파트}`)
        .then((response) => {
          commit("SET_REVIEWS", response.data);
          commit("SET_APTNAME", params);
        })
        .catch();
    },
    getTransTimePolice({ commit }, data) {
      const params = {
        apiKey: "a6ef10eb76e64e699e3ab12dc5ce6012",
        type: "all",
        minX: data.min1,
        minY: data.min2,
        maxX: data.max1,
        maxY: data.max2,
        getType: "json",
      };

      axios
        .get(`https://openapi.its.go.kr:9443/trafficInfo`, { params })
        .then((response) => {
          console.log(response.data.body.items);
          commit("SET_TRANCE_LIST_POLICE", response.data.body.items[0]);
        })
        .catch();
    },
    getTransTimeFire({ commit }, data) {
      console.log("소방서");
      const params = {
        apiKey: "a6ef10eb76e64e699e3ab12dc5ce6012",
        type: "all",
        minX: data.min1,
        minY: data.min2,
        maxX: data.max1,
        maxY: data.max2,
        getType: "json",
      };

      axios
        .get(`https://openapi.its.go.kr:9443/trafficInfo`, { params })
        .then((response) => {
          console.log("이거슨 ㅅ방서");
          console.log(response.data.body.items);
          commit("SET_TRANCE_LIST_FIRE", response.data.body.items[0]);
        })
        .catch();
    },
    getAptEtc({ commit }, house) {
      console.log(house);
      commit("SET_APTETC", house);
    },
    setReviewList({ commit }, param) {
      commit("SET_REVIEWLIST", param);
    },
    setSidoName({ commit }, param) {
      commit("SET_MYSIDO_NAME", param);
    },
    setGugunName({ commit }, param) {
      commit("SET_MYGUGUN_NAME", param);
    },
    setType({ commit }, param) {
      commit("SET_MYTYPE", param);
    },
  },

  getters: {
    reviews(state) {
      return state.reviews;
    },
    comments(state) {
      return state.comments;
    },
    types(state) {
      return state.myType;
    },
  },
  modules: { memberStore },
  plugins: [
    createPersistedState({
      // 브라우저 종료시 제거하기 위해 localStorage가 아닌 sessionStorage로 변경. (default: localStorage)
      storage: sessionStorage,
    }),
  ],
});
